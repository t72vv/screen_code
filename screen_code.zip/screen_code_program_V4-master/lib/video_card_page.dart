import 'package:flutter/material.dart';
import 'package:project/videos_details_page.dart';

class VideoCardWidget extends StatelessWidget {
  final int video_number;
  final String video_title;
  final String video_link;
  const VideoCardWidget(
      {super.key,
      required this.video_title,
      required this.video_number,
      required this.video_link});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 4),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.5), // لون الظل
            spreadRadius: 1, // نسبة انتشار الظل
            blurRadius: 1, // نسبة وضوح الظل
            offset: const Offset(0, 1), // إزاحة الظل
          ),
        ],
      ),
      child: ListTile(
        title: Row(
          children: [
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    video_title,
                    style: const TextStyle(fontSize: 17),
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  Text(
                    "$video_number",
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
          ],
        ),
        onTap: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => VideosDetailsWidgit(
                      appBar: "Python course Lesson",
                      video_number: video_number,
                      video_title: video_title,
                      video_link: video_link)));
        },
      ),
    );
  }
}
