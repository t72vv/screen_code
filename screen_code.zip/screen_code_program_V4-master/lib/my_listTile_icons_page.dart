import 'package:flutter/material.dart';
import 'package:project/auth/registre/view/LoginScreen%20.dart';

class MyListTileIcons extends StatelessWidget {
  final IconData icon;
  final String text;
  final Widget? page;
  const MyListTileIcons(
      {super.key, required this.icon, required this.text, this.page});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        height: MediaQuery.of(context).size.width * 0.15,
        padding: const EdgeInsets.all(1.5),
        margin: const EdgeInsets.all(4.5),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [
            Color(0xFFcef6ff),
            Color.fromARGB(255, 21, 206, 248),
          ], begin: Alignment.bottomLeft),
          border: Border.all(
            color: const Color.fromARGB(255, 176, 176, 176), // لون الحدود
            width: 1, // عرض الحدود
          ),
          color: Colors.white,
          borderRadius: BorderRadius.circular(15), // الزاوية المنحنية
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5), // لون الظل
              spreadRadius: 1, // نسبة انتشار الظل
              blurRadius: 2, // نسبة وضوح الظل
              offset: const Offset(0, 2), // إزاحة الظل
            ),
          ],
        ),
        child: ListTile(
          leading: Icon(icon, size: 35),
          title: Text(text, style: const TextStyle(fontSize: 25)),
          trailing: const Icon(Icons.arrow_forward_ios_rounded),
          onTap: () {
            if (page != null) {
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => page!));
            } else {
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (context) => const LoginScreen()),
              );
            }
          },
        ),
      ),
    );
  }
}
