import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:project/appbar_page.dart';
import 'package:project/courses-page/c++/cpp_course_page.dart';
import 'package:project/courses-page/css/css_course_page.dart';
import 'package:project/courses-page/html/html_course_page.dart';
import 'package:project/courses-page/java/java_course_page.dart';
import 'package:project/courses-page/javaScript/javaScript_course_page.dart';
import 'package:project/courses-page/python/python_course_page.dart';
import 'package:project/menu_page.dart';

List<dynamic> videosData = []; // تخزين البيانات المسترجعة هنا
int length = 0;

class CoursesWidgit extends StatefulWidget {
  const CoursesWidgit({super.key, required this.name});
  final String name;
  @override
  State<CoursesWidgit> createState() => _CoursesWidgitState();
}

class _CoursesWidgitState extends State<CoursesWidgit> {
  void getData() async {
    final QuerySnapshot snapshot =
        await FirebaseFirestore.instance.collection("PythonLessonsData").get();
    setState(() {
      // تحديث قائمة البيانات المحلية
      videosData = snapshot.docs.map((doc) => doc.data()).toList();
      length = videosData.length; // تحديث قيمة length هنا
    });
  }

  @override
  void initState() {
    super.initState();
    getData(); // استدعاء الدالة لجلب البيانات عند بناء الحاوية لأول مرة
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        drawer: MenuWidget(
          name: widget.name,
        ),
        backgroundColor: const Color(0xFFeffffe),
        appBar: const AppBarWidget(text: "Courses"),
        body: Expanded(
          child: Container(
            padding: const EdgeInsets.all(5),
            child: Expanded(
              child: GridView(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2),
                children: const [
                  Courses(img: "images/javaco.png", page: JavaCourseWidget()),
                  Courses(
                      img: "images/pythonco.png", page: PythonCourseWidget()),
                  Courses(img: "images/c++co.png", page: CppCourseWidget()),
                  Courses(img: "images/htmlco.png", page: HtmlCourseWidget()),
                  Courses(img: "images/cssco.png", page: CssCourseWidget()),
                  Courses(
                      img: "images/JSco.png", page: JavaScripCourseWidget()),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class Courses extends StatefulWidget {
  final String img;
  final Widget page;
  const Courses({super.key, required this.img, required this.page});
  @override
  State<Courses> createState() => _CoursesState();
}

class _CoursesState extends State<Courses> {
  @override
  Widget build(BuildContext context) {
    return InkWell(
        onTap: () {
          setState(() {
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => widget.page));
          });
        },
        child: Container(
          padding: const EdgeInsets.all(10),
          margin: const EdgeInsets.all(5),
          width: MediaQuery.of(context).size.width * 0.4,
          height: MediaQuery.of(context).size.width * 0.4,
          decoration: BoxDecoration(
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1), // لون الظل الخفيف
                spreadRadius: 1, // نسبة انتشار الظل
                blurRadius: 12, // نسبة وضوح الظل
                offset: const Offset(0, 1), // إزاحة الظل
              ),
            ],
            borderRadius: BorderRadius.circular(45),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(35),
            child: Image.asset(widget.img),
          ),
        ));
  }
}
