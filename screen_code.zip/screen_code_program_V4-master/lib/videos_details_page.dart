import 'package:flutter/material.dart';
import 'package:project/appbar_page.dart';
import 'package:project/test_page.dart';
import 'package:project/video_play_page.dart';

class VideosDetailsWidgit extends StatefulWidget {
  final String appBar;
  final int video_number;
  final String video_title;
  final String video_link;
  const VideosDetailsWidgit(
      {super.key,
      required this.appBar,
      required this.video_number,
      required this.video_title,
      required this.video_link});

  @override
  State<VideosDetailsWidgit> createState() => _VideosDetailsWidgitState();
}

class _VideosDetailsWidgitState extends State<VideosDetailsWidgit> {
  int _video_number = 0;
  String _video_title = "";
  String _video_link = "";
  Widget _video = Container();

  @override
  void initState() {
    setState(() {
      _video_number = widget.video_number;
      _video_title = widget.video_title;
      _video_link = widget.video_link;
      _video = Container(child: VideoPlayWidget(video: _video_link));
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: const Color(0xFFeffffe),
        appBar: AppBarWidget(text: widget.appBar),
        body: Expanded(
          child: Container(
            child: Column(children: [
              Container(
                height: 60,
                decoration: BoxDecoration(
                  borderRadius:
                      const BorderRadius.vertical(bottom: Radius.circular(20)),
                  color: const Color(0xFFbbf2fb),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.5),
                      spreadRadius: 3,
                      blurRadius: 7,
                      offset: const Offset(0, 1),
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.only(left: 20, right: 20),
                  child: Row(
                    mainAxisAlignment:
                        MainAxisAlignment.end, // تغيير المحاذاة هنا
                    children: [
                      Text(
                        _video_title,
                        style: const TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(width: 10),
                      const Icon(Icons.play_lesson_rounded),
                      const SizedBox(width: 10),
                      Text("$_video_number"),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 85),
              Container(
                  margin: const EdgeInsets.all(8),
                  child: Column(
                    children: [
                      //Text("num vid = $_video_number"),
                      _video,
                    ],
                  )),
            ]),
          ),
        ),
        bottomNavigationBar: Container(
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(20),
              topRight: Radius.circular(20),
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                spreadRadius: 1,
                blurRadius: 12,
                offset: const Offset(0, 1),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(20),
              topRight: Radius.circular(20),
            ),
            child: BottomAppBar(
              shape: const CircularNotchedRectangle(),
              color: Colors.white,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Expanded(
                    child: InkWell(
                      onTap: () {},
                      child: const Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.arrow_back_ios),
                          Text("back"),
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    child: SizedBox(
                      width: MediaQuery.of(context).size.height * 0.01,
                    ),
                  ),
                  Expanded(
                    child: SizedBox(
                      width: MediaQuery.of(context).size.height * 0.01,
                    ),
                  ),
                  Expanded(
                    child: InkWell(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => TestWidgit(
                                      appBar: widget.appBar,
                                      lesson_number: _video_number,
                                      lesson_title: _video_title,
                                    )));
                      },
                      child: const Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.arrow_forward_ios),
                          Text("next"),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
