import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:project/auth/controller/auth_cubit.dart';
import 'package:project/auth/controller/auth_state.dart';
import 'appbar_page.dart';

class ProfileWidget extends StatefulWidget {
  const ProfileWidget({super.key});

  @override
  State<ProfileWidget> createState() => _ProfileWidgetState();
}

class _ProfileWidgetState extends State<ProfileWidget> {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AuthCubit, AuthState>(
      builder: (context, state) {
        if (state is AuthSuccessState) {
          return SafeArea(
            child: Scaffold(
              backgroundColor: const Color(0xFFeffffe),
              appBar: const AppBarWidget(text: "Profile"),
              body: Center(
                child: Expanded(
                  child: Container(
                      child: Column(
                    children: [
                      SizedBox(
                        height: MediaQuery.of(context).size.width * 0.1,
                      ),
                      CircleAvatar(
                        backgroundColor: const Color(0xFFcbe2ff),
                        radius: MediaQuery.of(context).size.width * 0.18,
                        child: Icon(
                          Icons.person,
                          color: const Color(0xFF4a80aa),
                          size: MediaQuery.of(context).size.width * 0.25,
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(state.userData['name']),
                          IconButton(
                              onPressed: () {},
                              icon: const Icon(Icons.edit_square))
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.email_rounded),
                          Text(state.user.email!),
                          IconButton(
                              onPressed: () {},
                              icon: const Icon(Icons.edit_square))
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.phone),
                          Text(state.userData['phone']),
                          IconButton(
                              onPressed: () {},
                              icon: const Icon(Icons.edit_square))
                        ],
                      ),
                      const Row(
                        children: [
                          Icon(Icons.book_outlined),
                          Text("My courses")
                        ],
                      ),
                    ],
                  )),
                ),
              ),
            ),
          );
        } else {
          return const Center(child: CircularProgressIndicator());
        }
      },
    );
  }
}
