import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class MyListTileImage extends StatefulWidget {
  final String icon;
  final String text;
  final Widget? page;
  final String? community;

  const MyListTileImage(
      {super.key,
      required this.icon,
      required this.text,
      this.page,
      this.community});

  @override
  State<MyListTileImage> createState() => _MyListTileImageState();
}

class _MyListTileImageState extends State<MyListTileImage> {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.width * 0.15,
      padding: const EdgeInsets.all(1.5),
      margin: const EdgeInsets.all(4.5),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [
          Color(0xFFcef6ff),
          Color.fromARGB(255, 21, 206, 248),
        ], begin: Alignment.bottomLeft),
        border: Border.all(
          color: const Color.fromARGB(255, 255, 255, 255), // لون الحدود
          width: 1, // عرض الحدود
        ),
        color: Colors.white,
        borderRadius: BorderRadius.circular(15), // الزاوية المنحنية
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.5), // لون الظل
            spreadRadius: 1, // نسبة انتشار الظل
            blurRadius: 2, // نسبة وضوح الظل
            offset: const Offset(0, 2), // إزاحة الظل
          ),
        ],
      ),
      child: ListTile(
        leading: Image.asset(widget.icon, width: 35, height: 35),
        title: Text(widget.text,
            style: const TextStyle(
                fontSize: 25, color: Color.fromARGB(255, 0, 0, 0))),
        onTap: () {
          if (widget.page != null) {
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => widget.page!));
          } else {
            _launchURL(
                widget.community!); // استدعاء الدالة التي تقوم بفتح الرابط
          }
          setState(() {});
        },
      ),
    );
  }
}

_launchURL(community) async {
  String url = community; // رابط تطبيق التليجرام
  if (await canLaunch(url)) {
    await launch(url);
  } else {
    throw 'Could not launch $url';
  }
}
