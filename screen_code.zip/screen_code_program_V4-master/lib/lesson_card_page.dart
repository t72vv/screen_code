import 'package:flutter/material.dart';
import 'package:project/lesson_details_page.dart';

class LessonCardWidget extends StatelessWidget {
  final String appBar;
  final int lesson_number;
  final String lesson_title;
  final String lesson_link;
  const LessonCardWidget(
      {super.key,
      required this.appBar,
      required this.lesson_title,
      required this.lesson_number,
      required this.lesson_link});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 4),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.5), // لون الظل
            spreadRadius: 1, // نسبة انتشار الظل
            blurRadius: 1, // نسبة وضوح الظل
            offset: const Offset(0, 1), // إزاحة الظل
          ),
        ],
      ),
      child: ListTile(
        title: Row(
          children: [
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    lesson_title,
                    style: const TextStyle(fontSize: 17),
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  Text(
                    "$lesson_number",
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
          ],
        ),
        onTap: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => LessonDetailsWidgit(
                      appBar: appBar,
                      lesson_number: lesson_number,
                      lesson_title: lesson_title,
                      lesson_link: lesson_link)));
        },
      ),
    );
  }
}
