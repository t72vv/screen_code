import 'package:flutter/material.dart';
import 'package:project/appbar_page.dart';

class DeleteAccountWidgit extends StatefulWidget {
  const DeleteAccountWidgit({super.key});

  @override
  State<DeleteAccountWidgit> createState() => _DeleteAccountWidgitState();
}

class _DeleteAccountWidgitState extends State<DeleteAccountWidgit> {
  bool _showImage = false;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: const Color(0xFFeffffe),
        appBar: const AppBarWidget(text: "Delete My Account"),
        body: Center(
          child: Expanded(
            child: Container(
                padding: const EdgeInsets.only(left: 20, right: 20),
                margin: const EdgeInsets.all(2),
                child: Column(
                  children: [
                    SizedBox(
                      height: MediaQuery.of(context).size.width * 0.03,
                    ),
                    Row(
                      children: [
                        const SizedBox(width: 10),
                        Image.asset(
                          "images_icons/warning.png",
                          width: 35,
                        ),
                        const SizedBox(width: 14),
                        const Text("Warning", style: TextStyle(fontSize: 25)),
                      ],
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.width * 0.03,
                    ),
                    Container(
                      height: MediaQuery.of(context).size.width * 0.8,
                      padding: const EdgeInsets.all(20),
                      margin: const EdgeInsets.all(4.5),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: const Color.fromARGB(
                              255, 176, 176, 176), // لون الحدود
                          width: 1, // عرض الحدود
                        ),
                        color: Colors.white,
                        borderRadius:
                            BorderRadius.circular(15), // الزاوية المنحنية
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.5), // لون الظل
                            spreadRadius: 1, // نسبة انتشار الظل
                            blurRadius: 2, // نسبة وضوح الظل
                            offset: const Offset(0, 2), // إزاحة الظل
                          ),
                        ],
                      ),
                      child: const Text(
                        "We're sorry to see you go. Are you sure you want to delete your account? By doing so, you'll lose all your data and information permanently. We value your presence, and if there's anything we can do to improve your experience or address any issues you may be facing, please reach out to our customer service. If you still wish to proceed, please confirm your decision below.",
                        style: TextStyle(fontSize: 18),
                      ),
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.width * 0.05,
                    ),
                    ElevatedButton(
                      onPressed: () {
                        setState(() {
                          _showImage = true;
                        });
                        // العمليات التي تنفذ عند النقر على الزر
                      },
                      style: ElevatedButton.styleFrom(
                        foregroundColor: Colors.white,
                        backgroundColor: const Color(0xFF14DD06), // لون النص
                        shadowColor: Colors.grey, // لون الظل
                        elevation: 5, // ارتفاع الظل
                        shape: RoundedRectangleBorder(
                            borderRadius:
                                BorderRadius.circular(15) // حواف منحنية
                            ),
                        fixedSize: const Size(350, 80), // تحديد عرض الزر
                      ),
                      child: const Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.headphones_outlined),
                                SizedBox(width: 10),
                                Text(
                                  " Contact Customer Support ",
                                  style: TextStyle(fontSize: 18),
                                ),
                              ],
                            ),
                          ]),
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.width * 0.05,
                    ),
                    ElevatedButton(
                      onPressed: () {
                        setState(() {
                          _showImage = true;
                        });
                        // العمليات التي تنفذ عند النقر على الزر
                      },
                      style: ElevatedButton.styleFrom(
                        foregroundColor: Colors.white,
                        backgroundColor: const Color(0xFFFF0000), // لون النص
                        shadowColor: Colors.grey, // لون الظل
                        elevation: 5, // ارتفاع الظل
                        shape: RoundedRectangleBorder(
                            borderRadius:
                                BorderRadius.circular(15) // حواف منحنية
                            ),
                        fixedSize: const Size(220, 70), // تحديد عرض الزر
                      ),
                      child: const Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Row(
                              children: [
                                Icon(Icons.person_remove_sharp),
                                SizedBox(width: 10),
                                Text(
                                  " Delete Account ",
                                  style: TextStyle(fontSize: 18),
                                ),
                              ],
                            ),
                          ]),
                    ),
                    if (_showImage)
                      Expanded(
                        child: Container(
                          margin: const EdgeInsets.all(20),
                          child: Center(
                            child: Image.asset("images/soon.png"),
                          ),
                        ),
                      ),
                  ],
                )),
          ),
        ),
      ),
    );
  }
}
