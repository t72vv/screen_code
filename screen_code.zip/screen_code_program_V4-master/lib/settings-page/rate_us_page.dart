import 'package:flutter/material.dart';
import 'package:project/appbar_page.dart';

class RateUsWidgit extends StatefulWidget {
  const RateUsWidgit({super.key});

  @override
  State<RateUsWidgit> createState() => _RateUsWidgitState();
}

class _RateUsWidgitState extends State<RateUsWidgit> {
  bool _showImage = false;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: const Color(0xFFeffffe),
        appBar: const AppBarWidget(text: "Rate Us"),
        body: Center(
          child: Expanded(
            child: Container(
                padding: const EdgeInsets.only(left: 20, right: 20),
                margin: const EdgeInsets.all(2),
                child: Column(
                  children: [
                    SizedBox(
                      height: MediaQuery.of(context).size.width * 0.03,
                    ),
                    const Row(
                      children: [
                        Icon(Icons.sentiment_very_satisfied, size: 40),
                        SizedBox(width: 14),
                        Text("Rate Us", style: TextStyle(fontSize: 25)),
                      ],
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.width * 0.03,
                    ),
                    Container(
                      height: MediaQuery.of(context).size.width * 0.45,
                      padding: const EdgeInsets.all(20),
                      margin: const EdgeInsets.all(4.5),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: const Color.fromARGB(
                              255, 176, 176, 176), // لون الحدود
                          width: 1, // عرض الحدود
                        ),
                        color: Colors.white,
                        borderRadius:
                            BorderRadius.circular(15), // الزاوية المنحنية
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.5), // لون الظل
                            spreadRadius: 1, // نسبة انتشار الظل
                            blurRadius: 2, // نسبة وضوح الظل
                            offset: const Offset(0, 2), // إزاحة الظل
                          ),
                        ],
                      ),
                      child: const Text(
                        "🌟 Thank you for using our app! Did you enjoy your experience? Share your feedback with us by leaving a review, so we can continue to improve our service for you",
                        style: TextStyle(fontSize: 18),
                      ),
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.width * 0.02,
                    ),
                    ElevatedButton(
                      onPressed: () {
                        setState(() {
                          _showImage = true;
                        });
                        // العمليات التي تنفذ عند النقر على الزر
                      },
                      style: ElevatedButton.styleFrom(
                        foregroundColor: Colors.white,
                        backgroundColor: const Color(0xFF14DD06), // لون النص
                        shadowColor: Colors.grey, // لون الظل
                        elevation: 5, // ارتفاع الظل
                        shape: RoundedRectangleBorder(
                            borderRadius:
                                BorderRadius.circular(15) // حواف منحنية
                            ),
                        fixedSize: const Size(220, 80), // تحديد عرض الزر
                      ),
                      child: const Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              " Rate Us ",
                              style: TextStyle(fontSize: 18),
                            ),
                            Text(" ⭐⭐⭐⭐⭐ "),
                          ]),
                    ),
                    if (_showImage)
                      Expanded(
                        child: Container(
                          margin: const EdgeInsets.all(20),
                          child: Center(
                            child: Image.asset("images/soon.png"),
                          ),
                        ),
                      ),
                  ],
                )),
          ),
        ),
      ),
    );
  }
}
