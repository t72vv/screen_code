import 'package:flutter/material.dart';
import 'package:project/settings-page/settings_buttons_page.dart';

class NotificationsWidget extends StatefulWidget {
  const NotificationsWidget({super.key});

  @override
  State<NotificationsWidget> createState() => _NotificationsWidgetState();
}

class _NotificationsWidgetState extends State<NotificationsWidget> {
  @override
  Widget build(BuildContext context) {
    return const SettingsButtonsWidget(
      icon_title: Icons.notifications_active_rounded,
      title: "Notifications",
      icon_1: "images_icons/notificationsON.png",
      text_1: "ON",
      icon_2: "images_icons/notificationsOFF.png",
      text_2: "OFF",
      page_1: NotificationsWidget(),
      page_2: NotificationsWidget(),
    );
  }
}
