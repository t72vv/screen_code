import 'package:flutter/material.dart';
import 'package:project/settings-page/settings_buttons_page.dart';

class LanguageWidget extends StatefulWidget {
  const LanguageWidget({super.key});

  @override
  State<LanguageWidget> createState() => _LanguageWidgetState();
}

class _LanguageWidgetState extends State<LanguageWidget> {
  @override
  Widget build(BuildContext context) {
    return const SettingsButtonsWidget(
      icon_title: Icons.language,
      title: "Language",
      icon_1: "images_icons/Arabic.png",
      text_1: "Arabic",
      icon_2: "images_icons/English.png",
      text_2: "English",
      page_1: LanguageWidget(),
      page_2: LanguageWidget(),
    );
  }
}
