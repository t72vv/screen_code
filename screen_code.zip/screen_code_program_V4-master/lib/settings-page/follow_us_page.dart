import 'package:flutter/material.dart';
import 'package:project/settings-page/settings_buttons_page.dart';

class FollowUsWidget extends StatefulWidget {
  const FollowUsWidget({super.key});

  @override
  State<FollowUsWidget> createState() => _FollowUsWidgetState();
}

class _FollowUsWidgetState extends State<FollowUsWidget> {
  @override
  Widget build(BuildContext context) {
    return const SettingsButtonsWidget(
      icon_title: Icons.person_add_sharp,
      title: "Follow Us",
      icon_1: "images_icons/youtube.png",
      text_1: "Youtube",
      icon_2: "images_icons/telegram.png",
      text_2: "Telegram",
      page_1: FollowUsWidget(),
      page_2: FollowUsWidget(),
    );
  }
}
