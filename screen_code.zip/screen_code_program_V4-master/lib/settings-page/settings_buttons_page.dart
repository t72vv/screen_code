import 'package:flutter/material.dart';
import 'package:project/appbar_page.dart';
import 'package:project/my_listTile_image_page.dart';

class SettingsButtonsWidget extends StatelessWidget {
  final IconData icon_title;
  final String title;
  final String icon_1;
  final String text_1;
  final String icon_2;
  final String text_2;
  final Widget page_1;
  final Widget page_2;
  const SettingsButtonsWidget(
      {super.key,
      required this.icon_title,
      required this.title,
      required this.icon_1,
      required this.text_1,
      required this.icon_2,
      required this.text_2,
      required this.page_1,
      required this.page_2});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: const Color(0xFFeffffe),
        appBar: AppBarWidget(text: title),
        body: Center(
          child: Expanded(
            child: Container(
                padding: const EdgeInsets.only(left: 20, right: 20),
                margin: const EdgeInsets.all(2),
                child: Column(
                  children: [
                    SizedBox(
                      height: MediaQuery.of(context).size.width * 0.03,
                    ),
                    Row(
                      children: [
                        Icon(icon_title, size: 40, color: Colors.blue),
                        const SizedBox(width: 14),
                        Text(title,
                            style: const TextStyle(
                                fontSize: 25, color: Colors.blue)),
                      ],
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.width * 0.03,
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.width * 0.7,
                      child: Expanded(
                        child: ListView(
                          children: [
                            MyListTileImage(
                              icon: icon_1,
                              text: text_1,
                              page: page_1,
                            ),
                            MyListTileImage(
                              icon: icon_2,
                              text: text_2,
                              page: page_2,
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.width * 0.02,
                    ),
                  ],
                )),
          ),
        ),
      ),
    );
  }
}
