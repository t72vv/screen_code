import 'package:flutter/material.dart';
import 'package:project/settings-page/settings_buttons_page.dart';

class LinkedAccountsWidget extends StatefulWidget {
  const LinkedAccountsWidget({super.key});

  @override
  State<LinkedAccountsWidget> createState() => _LinkedAccountsWidgetState();
}

class _LinkedAccountsWidgetState extends State<LinkedAccountsWidget> {
  @override
  Widget build(BuildContext context) {
    return const SettingsButtonsWidget(
      icon_title: Icons.add_link_sharp,
      title: "Linked Accounts",
      icon_1: "images_icons/google.png",
      text_1: "Google",
      icon_2: "images_icons/github.png",
      text_2: "Github",
      page_1: LinkedAccountsWidget(),
      page_2: LinkedAccountsWidget(),
    );
  }
}
