import 'package:flutter/material.dart';
import 'package:project/settings-page/settings_buttons_page.dart';

class HelpWidget extends StatefulWidget {
  const HelpWidget({super.key});

  @override
  State<HelpWidget> createState() => _HelpWidgetState();
}

class _HelpWidgetState extends State<HelpWidget> {
  @override
  Widget build(BuildContext context) {
    return const SettingsButtonsWidget(
      icon_title: Icons.headset_mic_sharp,
      title: "Help",
      icon_1: "images_icons/live-chat.png",
      text_1: "Live chat",
      icon_2: "images_icons/Social-Media-help.png",
      text_2: "Social Media",
      page_1: HelpWidget(),
      page_2: HelpWidget(),
    );
  }
}
