import 'package:flutter/material.dart';
import 'package:project/appbar_page.dart';
import 'package:project/settings-page/change_password_page.dart';
import 'package:project/settings-page/delete_account_page.dart';
import 'package:project/settings-page/follow_us_page.dart';
import 'package:project/settings-page/help_page.dart';
import 'package:project/settings-page/language_page.dart';
import 'package:project/menu_page.dart';
import 'package:project/my_listTile_icons_page.dart';
import 'package:project/settings-page/linked_accounts_page.dart';
import 'package:project/settings-page/notifications_page.dart';
import 'package:project/settings-page/rate_us_page.dart';

class SettingsWidgit extends StatefulWidget {
  const SettingsWidgit({super.key, required this.name});
  final String name;
  @override
  State<SettingsWidgit> createState() => _SettingsWidgitState();
}

class _SettingsWidgitState extends State<SettingsWidgit> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        drawer: MenuWidget(
          name: widget.name,
        ),
        backgroundColor: const Color(0xFFeffffe),
        appBar: const AppBarWidget(text: "Settings"),
        body: Center(
          child: Expanded(
            child: Container(
                padding: const EdgeInsets.only(left: 20, right: 20),
                margin: const EdgeInsets.all(2),
                child: Column(
                  children: [
                    SizedBox(
                      height: MediaQuery.of(context).size.width * 0.03,
                    ),
                    const Row(
                      children: [
                        Icon(Icons.settings, size: 40),
                        SizedBox(width: 14),
                        Text("Settings", style: TextStyle(fontSize: 25)),
                      ],
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.width * 0.03,
                    ),
                    Expanded(
                      child: ListView(
                        children: const [
                          MyListTileIcons(
                              icon: Icons.lock_reset,
                              text: "Change Password",
                              page: ChangePasswordWidgit()),
                          MyListTileIcons(
                              icon: Icons.language,
                              text: "Language",
                              page: LanguageWidget()),
                          MyListTileIcons(
                              icon: Icons.notifications_active_rounded,
                              text: "Notifications",
                              page: NotificationsWidget()),
                          MyListTileIcons(
                              icon: Icons.link,
                              text: "Linked Accounts",
                              page: LinkedAccountsWidget()),
                          MyListTileIcons(
                              icon: Icons.star,
                              text: "Rate Us",
                              page: RateUsWidgit()),
                          MyListTileIcons(
                              icon: Icons.person_add_sharp,
                              text: "Follow Us",
                              page: FollowUsWidget()),
                          MyListTileIcons(
                              icon: Icons.headset_mic_sharp,
                              text: "Help",
                              page: HelpWidget()),
                          MyListTileIcons(
                              icon: Icons.person_remove_sharp,
                              text: "Delete My Account",
                              page: DeleteAccountWidgit()),
                          MyListTileIcons(
                            icon: Icons.logout,
                            text: "Log out",
                          ),
                        ],
                      ),
                    )
                  ],
                )),
          ),
        ),
      ),
    );
  }
}
