import 'package:flutter/material.dart';
import 'package:project/appbar_page.dart';
import 'package:project/my_listTile_image_page.dart';

class ChangePasswordWidgit extends StatefulWidget {
  const ChangePasswordWidgit({Key? key}) : super(key: key);

  @override
  State<ChangePasswordWidgit> createState() => _ChangePasswordWidgitState();
}

class _ChangePasswordWidgitState extends State<ChangePasswordWidgit> {
  bool _showImage = false;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: const Color(0xFFeffffe),
        appBar: const AppBarWidget(text: "Change Password"),
        body: Center(
          child: Expanded(
            child: Container(
              padding: const EdgeInsets.only(left: 20, right: 20),
              margin: const EdgeInsets.all(2),
              child: Column(
                children: [
                  SizedBox(
                    height: MediaQuery.of(context).size.width * 0.03,
                  ),
                  const Row(
                    children: [
                      Icon(Icons.lock_reset, size: 40, color: Colors.blue),
                      SizedBox(width: 14),
                      Text("Change Password",
                          style: TextStyle(fontSize: 25, color: Colors.blue)),
                    ],
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.width * 0.03,
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.width * 0.7,
                    child: Expanded(
                      child: ListView(
                        children: const [
                          MyListTileImage(
                            icon: "images_icons/Current_Password.png",
                            text: "Current Password",
                            page: ChangePasswordWidgit(),
                          ),
                          MyListTileImage(
                            icon: "images_icons/New_Password.png",
                            text: "New Password",
                            page: ChangePasswordWidgit(),
                          ),
                          MyListTileImage(
                            icon: "images_icons/reset_password.png",
                            text: "Confirm Password",
                            page: ChangePasswordWidgit(),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.width * 0.02,
                  ),
                  ElevatedButton(
                    onPressed: () {
                      setState(() {
                        _showImage = true;
                      });
                    },
                    style: ElevatedButton.styleFrom(
                      foregroundColor: Colors.white,
                      backgroundColor: Colors.blue, // لون النص
                      shadowColor: Colors.grey, // لون الظل
                      elevation: 5, // ارتفاع الظل
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(45) // حواف منحنية
                          ),
                      fixedSize: const Size(240, 80), // تحديد عرض الزر
                    ),
                    child: const Text(
                      "Change Password",
                      style: TextStyle(fontSize: 18),
                    ),
                  ),
                  // عرض الصورة إذا كان _showImage يساوي true
                  if (_showImage)
                    Expanded(
                      child: Container(
                        margin: const EdgeInsets.all(20),
                        child: Center(
                          child: Image.asset("images/soon.png"),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
