import 'package:flutter/material.dart';
import 'package:project/appbar_page.dart';
import 'package:project/menu_page.dart';

class SearchWidgit extends StatefulWidget {
  const SearchWidgit({super.key, required this.name});

  final String name;

  @override
  State<SearchWidgit> createState() => _SearchWidgitState();
}

class _SearchWidgitState extends State<SearchWidgit> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        drawer: MenuWidget(
          name: widget.name,
        ),
        backgroundColor: const Color(0xFFeffffe),
        appBar: const AppBarWidget(text: "Search"),
        body: Expanded(
          child: Container(
            child: Column(
              children: [
                Container(
                  height: 60,
                  decoration: BoxDecoration(
                    borderRadius: const BorderRadius.vertical(
                        bottom: Radius.circular(20)),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5), // لون الظل
                        spreadRadius: 3, // نسبة انتشار الظل
                        blurRadius: 7, // نسبة وضوح الظل
                        offset: const Offset(0, 1), // إزاحة الظل
                      ),
                    ],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: Row(
                      children: [
                        const Expanded(
                          child: TextField(
                            decoration: InputDecoration(
                              hintText: "Search",
                              border: OutlineInputBorder(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(25))),
                            ),
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.search),
                          onPressed: () {},
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
