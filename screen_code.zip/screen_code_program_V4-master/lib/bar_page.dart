import 'package:flutter/material.dart';
import 'package:google_nav_bar/google_nav_bar.dart';
import 'package:project/information_page.dart';
import 'package:project/search_page.dart';
import 'package:project/courses_page.dart';
import 'package:project/home_page.dart';
import 'package:project/settings-page/settings_page.dart';

class BarWidgit extends StatefulWidget {
  const BarWidgit({super.key, required this.name}); // Add required
  final String name;

  @override
  State<BarWidgit> createState() => _BarWidgitState();
}

class _BarWidgitState extends State<BarWidgit> {
  int _selectedIndex = 2;

  List<Widget> get barOptions => <Widget>[
        SettingsWidgit(name: widget.name),
        CoursesWidgit(
          name: widget.name,
        ),
        HomeWidgit(
          name: widget.name,
        ),
        SearchWidgit(
          name: widget.name,
        ),
        InformationWidgit(name: widget.name)
      ];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: barOptions.elementAt(_selectedIndex),
        bottomNavigationBar: GNav(
          gap: 5,
          backgroundColor: Colors.white,
          tabBackgroundColor: const Color(0xFF42d4f5),
          activeColor: const Color.fromARGB(255, 255, 255, 255),
          tabMargin: const EdgeInsets.only(bottom: 7, top: 7),
          padding: const EdgeInsets.all(14),
          selectedIndex: _selectedIndex,
          onTabChange: (value) {
            setState(() {
              _selectedIndex = value;
            });
          },
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          tabs: const [
            GButton(icon: Icons.settings, text: "Settings"),
            GButton(icon: Icons.menu_book_rounded, text: "Courses"),
            GButton(icon: Icons.home, text: "Home"),
            GButton(icon: Icons.search, text: "Search"),
            GButton(icon: Icons.question_mark_outlined, text: "Information"),
          ],
        ),
      ),
    );
  }
}
