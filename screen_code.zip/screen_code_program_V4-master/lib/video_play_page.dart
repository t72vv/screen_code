import 'package:flutter/material.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

// ignore: must_be_immutable
class VideoPlayWidget extends StatefulWidget {
  String video;
  VideoPlayWidget({Key? key, required this.video}) : super(key: key);

  @override
  State<VideoPlayWidget> createState() => _VideoPlayWidgetState();
}

class _VideoPlayWidgetState extends State<VideoPlayWidget> {
  late YoutubePlayerController _controller;

  @override
  void initState() {
    setState(() {
      // تحويل رابط الفيديو إلى معرف الفيديو في يوتيوب
      final videoID = YoutubePlayer.convertUrlToId(widget.video);
      // إنشاء مراقب لتحكم في الفيديو
      _controller = YoutubePlayerController(
        initialVideoId: videoID ??
            '', // يمكنك التحقق من القيمة المسترجعة من convertUrlToId لتجنب الأخطاء
        flags: const YoutubePlayerFlags(autoPlay: false),
      );
      super.initState();
    });
  }

  @override
  Widget build(BuildContext context) {
    return YoutubePlayer(
      controller: _controller,
      showVideoProgressIndicator: true,
    );
  }
}
