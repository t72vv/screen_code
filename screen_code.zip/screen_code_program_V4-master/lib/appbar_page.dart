import 'package:flutter/material.dart';

class AppBarWidget extends StatelessWidget implements PreferredSizeWidget {
  final String text;
  const AppBarWidget({Key? key, required this.text}) : super(key: key);

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: Colors.white,
      //automaticallyImplyLeading: false,
      //leading: IconButton(icon: Icon(Icons.menu, size: 40), onPressed: () {}),
      title: Center(child: Text(text)),
      actions: [Image.asset("images/logoSC.png")],
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(8.0), // ارتفاع الظل
        child: Container(
          decoration: BoxDecoration(
            boxShadow: [
              BoxShadow(
                color: const Color.fromARGB(255, 125, 125, 125)
                    .withOpacity(0.5), // لون الظل
                spreadRadius: 1.5, // نطاق الانتشار
                blurRadius: 8, // نسبة التشويش
                offset: const Offset(0, 1), // الإزاحة (الارتفاع من الأسفل)
              ),
            ],
          ),
        ),
      ),
    );
  }
}
