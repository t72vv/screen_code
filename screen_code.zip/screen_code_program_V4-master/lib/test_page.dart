import 'package:flutter/material.dart';
import 'package:project/appbar_page.dart';
import 'package:project/courses-page/course_widget_page.dart';
import 'package:project/courses-page/python/python_course_lessons_page.dart';
import 'package:project/courses_page.dart';
import 'package:project/data/questions_data.dart';

class TestWidgit extends StatefulWidget {
  final String appBar;
  final int lesson_number;
  final String lesson_title;

  const TestWidgit(
      {super.key,
      required this.lesson_number,
      required this.lesson_title,
      required this.appBar});

  @override
  State<TestWidgit> createState() => _TestWidgitState();
}

class _TestWidgitState extends State<TestWidgit> {
  bool isCorrect = true;
  String selectedAnswer = '';
  int _lesson_number = 0;
  String? _lesson_title;

  void checkAnswer(String answer, String correctAnswer) {
    setState(() {
      selectedAnswer = answer;
      if (answer == correctAnswer) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Correct!',
              style: TextStyle(color: Colors.green),
            ),
            backgroundColor: Colors.white,
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Wrong! The correct answer is: $correctAnswer',
              style: const TextStyle(color: Colors.red),
            ),
            backgroundColor: Colors.white,
          ),
        );
      }
    });
  }

  @override
  void initState() {
    setState(() {
      _lesson_number = widget.lesson_number;
      _lesson_title = widget.lesson_title;
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: const Color(0xFFeffffe),
        appBar: AppBarWidget(text: widget.appBar),
        body: Expanded(
          child: Container(
            child: Column(
              children: [
                Container(
                  height: 60,
                  decoration: BoxDecoration(
                    borderRadius: const BorderRadius.vertical(
                        bottom: Radius.circular(20)),
                    color: const Color(0xFFbbf2fb),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 3,
                        blurRadius: 7,
                      ),
                    ],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.only(left: 20, right: 20),
                    child: Row(
                      mainAxisAlignment:
                          MainAxisAlignment.end, // تغيير المحاذاة هنا
                      children: [
                        Text(
                          _lesson_title!,
                          style: const TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(width: 10),
                        const Icon(Icons.play_lesson_rounded),
                        const SizedBox(width: 10),
                        Text("$_lesson_number"),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 45),
                Expanded(
                  child: Container(
                    margin: const EdgeInsets.all(15),
                    padding: const EdgeInsets.only(
                        top: 10, bottom: 10, right: 20, left: 20),
                    width: MediaQuery.of(context).size.width,
                    child: Column(children: [
                      Text(
                        questions[widget.lesson_number - 1]["question"],
                        style: const TextStyle(fontSize: 22),
                      ),
                      const SizedBox(height: 25),
                      const Row(
                        children: [
                          Expanded(
                            child: Divider(
                              color: Colors.black,
                              thickness: 2,
                              endIndent: 20,
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 8.0),
                            child: Text(
                              "Options",
                              style: TextStyle(
                                  fontSize: 22, fontWeight: FontWeight.bold),
                            ),
                          ),
                          Expanded(
                            child: Divider(
                              color: Colors.black,
                              thickness: 2,
                              indent: 20,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 25),
                      Column(
                        children: List.generate(
                          questions[widget.lesson_number - 1]['answers'].length,
                          (answerIndex) {
                            String answer = questions[widget.lesson_number - 1]
                                ['answers'][answerIndex];
                            bool isCorrect = answer ==
                                questions[widget.lesson_number - 1]
                                    ['correctAnswer'];
                            return InkWell(
                              onTap: () {
                                checkAnswer(
                                    answer,
                                    questions[widget.lesson_number - 1]
                                        ['correctAnswer']);
                              },
                              child: Container(
                                width: MediaQuery.of(context).size.width,
                                height:
                                    MediaQuery.of(context).size.height * 0.06,
                                margin: const EdgeInsets.symmetric(vertical: 5),
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [
                                      selectedAnswer == answer
                                          ? isCorrect
                                              ? Colors.greenAccent
                                                  .withOpacity(0.8)
                                              : const Color.fromARGB(
                                                      255, 255, 0, 0)
                                                  .withOpacity(0.8)
                                          : Colors.white.withOpacity(0.8),
                                      selectedAnswer == answer
                                          ? isCorrect
                                              ? const Color.fromARGB(
                                                      255, 0, 220, 114)
                                                  .withOpacity(0.6)
                                              : Colors.redAccent
                                                  .withOpacity(0.6)
                                          : Colors.white.withOpacity(0.6),
                                    ],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                                  border: Border.all(
                                    color: selectedAnswer == answer
                                        ? isCorrect
                                            ? const Color.fromARGB(
                                                255, 8, 216, 116)
                                            : Colors.redAccent
                                        : Colors.black,
                                  ),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Text(
                                  answer,
                                  style: const TextStyle(fontSize: 18),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ]),
                  ),
                )
              ],
            ),
          ),
        ),
        bottomNavigationBar: Container(
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(20),
              topRight: Radius.circular(20),
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                spreadRadius: 1,
                blurRadius: 12,
                offset: const Offset(0, 1),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(20),
              topRight: Radius.circular(20),
            ),
            child: BottomAppBar(
              shape: const CircularNotchedRectangle(),
              color: Colors.white,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Expanded(
                    child: InkWell(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: const Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.arrow_back_ios),
                          Text("back"),
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    child: SizedBox(
                      width: MediaQuery.of(context).size.height * 0.01,
                    ),
                  ),
                  Expanded(
                    child: SizedBox(
                      width: MediaQuery.of(context).size.height * 0.01,
                    ),
                  ),
                  Expanded(
                    child: InkWell(
                      onTap: () {
                        setState(() {
                          completed++;
                          remaining = length - completed;
                        });

                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    const PythonCourseLessonsWidget()));
                      },
                      child: const Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.arrow_forward_ios),
                          Text("next"),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
