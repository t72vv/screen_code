import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'auth_state.dart';

class AuthCubit extends Cubit<AuthState> {
  AuthCubit() : super(AuthInitialState());

  static AuthCubit get(context) => BlocProvider.of(context);

  final FirebaseAuth _auth = FirebaseAuth.instance;

  Future<void> signInWithEmailAndPassword(String email, String password) async {
    emit(AuthLoadingState());
    try {
      UserCredential userCredential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      User? user = userCredential.user;
      if (user != null) {
        // Fetch additional user data from Firestore
        DocumentSnapshot userData = await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .get();
        emit(AuthSuccessState(user, userData));
      }
    } on FirebaseAuthException catch (e) {
      emit(AuthFailureState(e.message!));
    }
  }

  Future<void> signUpWithEmailAndPassword(
      String email, String password, String name, String phone) async {
    emit(AuthLoadingState());
    try {
      UserCredential userCredential = await _auth
          .createUserWithEmailAndPassword(email: email, password: password);
      User? user = userCredential.user;
      if (user != null) {
        CollectionReference usersCollection =
            FirebaseFirestore.instance.collection('users');
        await usersCollection.doc(user.uid).set({
          'name': name,
          'phone': phone,
        });

        // Fetch additional user data from Firestore
        DocumentSnapshot userData = await usersCollection.doc(user.uid).get();
        emit(AuthSuccessState(user, userData));
      }
    } on FirebaseAuthException catch (e) {
      emit(AuthFailureState(e.message!));
    }
  }

  Future<void> signOut() async {
    await _auth.signOut();
    emit(AuthInitialState());
  }
}
