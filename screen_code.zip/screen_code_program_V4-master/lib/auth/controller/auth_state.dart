import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

abstract class AuthState {}

class AuthInitialState extends AuthState {}

class AuthLoadingState extends AuthState {}

class AuthSuccessState extends AuthState {
  final User user;
  final DocumentSnapshot userData;

  AuthSuccessState(this.user, this.userData);
}

class AuthFailureState extends AuthState {
  final String error;

  AuthFailureState(this.error);
}
