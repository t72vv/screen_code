import 'package:flutter/material.dart';
import 'package:project/appbar_page.dart';
import 'package:project/menu_page.dart';

var my_style = TextStyle(fontSize: 25);

class InformationWidgit extends StatefulWidget {
  const InformationWidgit({super.key, required this.name});
  final String name;
  @override
  State<InformationWidgit> createState() => _InformationWidgitState();
}

class _InformationWidgitState extends State<InformationWidgit> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        drawer: MenuWidget(
          name: widget.name,
        ),
        backgroundColor: const Color(0xFFeffffe),
        appBar: const AppBarWidget(text: "Information"),
        body: Container(
          padding: const EdgeInsets.all(8),
          child: Column(
            children: [
              SizedBox(height: 10),
              Row(
                children: [
                  Image.asset("images/info.png",
                      width: MediaQuery.of(context).size.width * 0.08),
                  const Text(
                    "Information",
                    style: TextStyle(fontSize: 25),
                  )
                ],
              ),
              SizedBox(height: 10),
              Expanded(
                child: Container(
                  margin: const EdgeInsets.all(6),
                  padding: const EdgeInsets.all(10),
                  width: MediaQuery.of(context).size.width * 0.95,
                  height: MediaQuery.of(context).size.width * 1.56,
                  decoration: BoxDecoration(
                      borderRadius: const BorderRadius.all(
                        Radius.circular(15),
                      ),
                      color: Colors.white,
                      border: Border.all(color: Colors.black, width: 1)),
                  child: const Column(children: [
                    SizedBox(height: 10),
                    Row(
                      children: [
                        Icon(
                          Icons.lightbulb,
                          size: 35,
                        ),
                        SizedBox(width: 10),
                        Text(
                          "Introduction",
                          style: TextStyle(fontSize: 25),
                        )
                      ],
                    ),
                    SizedBox(height: 10),
                    Text(
                      "Welcome to Screen Code, where you can explore and learn programming languages in a fun and effective way.",
                      style: TextStyle(fontSize: 18),
                    ),
                    SizedBox(height: 20),
                    Row(
                      children: [
                        Icon(
                          Icons.track_changes_rounded,
                          size: 35,
                        ),
                        SizedBox(width: 10),
                        Text(
                          "App Objectives",
                          style: TextStyle(fontSize: 25),
                        )
                      ],
                    ),
                    SizedBox(height: 10),
                    Text(
                      "Our goal is to provide comprehensive and innovative educational content to help develop programming skills from basic to advanced levels.",
                      style: TextStyle(fontSize: 18),
                    ),
                    SizedBox(height: 20),
                    Row(
                      children: [
                        Icon(
                          Icons.play_lesson_rounded,
                          size: 35,
                        ),
                        SizedBox(width: 10),
                        Text(
                          "Courses and Lessons",
                          style: TextStyle(fontSize: 25),
                        )
                      ],
                    ),
                    SizedBox(height: 10),
                    Text(
                      "Discover a variety of courses and lessons .",
                      style: TextStyle(fontSize: 18),
                    ),
                  ]),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
