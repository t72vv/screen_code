import 'package:flutter/material.dart';
import 'package:project/courses-page/course_widget_page.dart';
import 'package:project/courses-page/javaScript/javaScript_course_lessons_page.dart';

class JavaScripCourseWidget extends StatefulWidget {
  const JavaScripCourseWidget({super.key});

  @override
  State<JavaScripCourseWidget> createState() => _JavaScripCourseWidgetState();
}

class _JavaScripCourseWidgetState extends State<JavaScripCourseWidget> {
  @override
  Widget build(BuildContext context) {
    return const CourseWidget(
      title: "JavaScrip course",
      img: "images/python_course_img.jpg",
      page: JavaScriptCourseLessonsWidget(),
    );
  }
}
