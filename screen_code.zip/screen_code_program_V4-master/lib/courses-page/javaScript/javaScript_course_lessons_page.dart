import 'package:flutter/material.dart';
import 'package:project/courses-page/course_lessons_page.dart';
import 'package:project/data/JS_lesson_data.dart';

class JavaScriptCourseLessonsWidget extends StatefulWidget {
  const JavaScriptCourseLessonsWidget({super.key});

  @override
  State<JavaScriptCourseLessonsWidget> createState() =>
      _JavaScriptCourseLessonsWidgetState();
}

class _JavaScriptCourseLessonsWidgetState
    extends State<JavaScriptCourseLessonsWidget> {
  @override
  Widget build(BuildContext context) {
    return const CourseLessonsWidget(
      title: "JavaScrip course",
      img: "images/python_course_img.jpg",
      page: JSLessonDataWidget(),
    );
  }
}
