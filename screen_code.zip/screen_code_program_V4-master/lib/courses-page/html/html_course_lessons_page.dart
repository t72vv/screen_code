import 'package:flutter/material.dart';
import 'package:project/courses-page/course_lessons_page.dart';
import 'package:project/data/html_lesson_data.dart';

class HtmlCourseLessonsWidget extends StatefulWidget {
  const HtmlCourseLessonsWidget({super.key});

  @override
  State<HtmlCourseLessonsWidget> createState() =>
      _HtmlCourseLessonsWidgetState();
}

class _HtmlCourseLessonsWidgetState extends State<HtmlCourseLessonsWidget> {
  @override
  Widget build(BuildContext context) {
    return const CourseLessonsWidget(
      title: "HTML course",
      img: "images/python_course_img.jpg",
      page: HTMLLessonDataWidget(),
    );
  }
}
