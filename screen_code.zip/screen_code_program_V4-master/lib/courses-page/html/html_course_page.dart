import 'package:flutter/material.dart';
import 'package:project/courses-page/course_widget_page.dart';
import 'package:project/courses-page/html/html_course_lessons_page.dart';

class HtmlCourseWidget extends StatefulWidget {
  const HtmlCourseWidget({super.key});

  @override
  State<HtmlCourseWidget> createState() => _HtmlCourseWidgetState();
}

class _HtmlCourseWidgetState extends State<HtmlCourseWidget> {
  @override
  Widget build(BuildContext context) {
    return const CourseWidget(
      title: "HTML course",
      img: "images/python_course_img.jpg",
      page: HtmlCourseLessonsWidget(),
    );
  }
}
