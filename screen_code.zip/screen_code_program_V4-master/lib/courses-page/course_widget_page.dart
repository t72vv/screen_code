import 'package:flutter/material.dart';
import 'package:project/appbar_page.dart';
import 'package:project/courses_page.dart';
import 'package:project/my_listTile_image_page.dart';
import 'package:percent_indicator/percent_indicator.dart';

int completed = 0;
int remaining = length - completed;

class CourseWidget extends StatefulWidget {
  final String title;
  final String img;
  final Widget page;
  const CourseWidget(
      {Key? key, required this.img, required this.title, required this.page})
      : super(key: key);

  @override
  State<CourseWidget> createState() => _CourseWidgetState();
}

class _CourseWidgetState extends State<CourseWidget> {
  double percentage = (completed / length) * 100;

  @override
  Widget build(BuildContext context) {
    String formattedPercentage = (percentage).toStringAsFixed(2);

    return SafeArea(
      child: Scaffold(
        backgroundColor: const Color(0xFFeffffe),
        appBar: AppBarWidget(text: widget.title),
        body: Container(
          color: const Color(0xFFeffffe),
          child: Column(
            children: [
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.only(left: 20, right: 20),
                margin: const EdgeInsets.all(25),
                height: MediaQuery.of(context).size.width * 0.560,
                decoration: BoxDecoration(
                  color: const Color.fromARGB(255, 255, 255, 255),
                  borderRadius: const BorderRadius.only(
                      bottomLeft: Radius.circular(15),
                      bottomRight: Radius.circular(15),
                      topLeft: Radius.circular(15),
                      topRight: Radius.circular(120)), // الزاوية المنحنية
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.5), // لون الظل
                      spreadRadius: 1, // نسبة انتشار الظل
                      blurRadius: 2, // نسبة وضوح الظل
                      offset: const Offset(0, 2), // إزاحة الظل
                    ),
                  ],
                ),
                child: Expanded(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const SizedBox(height: 45),
                          Expanded(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const VerticalDivider(
                                  color: Color.fromARGB(255, 55, 255, 0),
                                  thickness: 2.0,
                                  width: 10,
                                  indent: 2,
                                  endIndent: 50,
                                ),
                                const SizedBox(width: 10),
                                Column(
                                  children: [
                                    const Text(
                                      "Completed",
                                      style: TextStyle(
                                        color: Color.fromARGB(255, 55, 255, 0),
                                      ),
                                    ),
                                    const SizedBox(height: 5),
                                    Text("$completed"),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          Expanded(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const VerticalDivider(
                                  color: Color.fromARGB(255, 255, 0, 0),
                                  thickness: 2.0,
                                  width: 10,
                                  indent: 2,
                                  endIndent: 50,
                                ),
                                const SizedBox(width: 10),
                                Column(
                                  children: [
                                    const Text(
                                      "Remaining",
                                      style: TextStyle(
                                        color: Color.fromARGB(255, 255, 0, 0),
                                      ),
                                    ),
                                    const SizedBox(height: 5),
                                    Text("$remaining"),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      //الدائرة للنسبة المئوية
                      CircularPercentIndicator(
                        animation: true,
                        animationDuration: 1500,
                        radius: 65,
                        lineWidth: 15,
                        percent: percentage / 100,
                        progressColor: const Color.fromARGB(255, 26, 101, 251),
                        backgroundColor:
                            const Color.fromARGB(255, 206, 246, 255),
                        circularStrokeCap: CircularStrokeCap.round,
                        center: Text("$formattedPercentage %"),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.only(left: 20, right: 20),
                margin: const EdgeInsets.all(2),
                child: Column(
                  children: [
                    MyListTileImage(
                      icon: "images_icons/lesson.png",
                      text: "Course Lessons",
                      page: widget.page,
                    ),
                    const SizedBox(height: 15),
                    const MyListTileImage(
                      icon: "images_icons/community.png",
                      text: "Community",
                      community: 'https://t.me/+M7bzz7ld4FVmNmU0',
                      //page: widget.page,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
