import 'package:flutter/material.dart';
import 'package:project/courses-page/course_lessons_page.dart';
import 'package:project/data/css_lesson_data.dart';

class CssCourseLessonsWidget extends StatefulWidget {
  const CssCourseLessonsWidget({super.key});

  @override
  State<CssCourseLessonsWidget> createState() => _CssCourseLessonsWidgetState();
}

class _CssCourseLessonsWidgetState extends State<CssCourseLessonsWidget> {
  @override
  Widget build(BuildContext context) {
    return const CourseLessonsWidget(
      title: "Css course",
      img: "images/python_course_img.jpg",
      page: CssLessonDataWidget(),
    );
  }
}
