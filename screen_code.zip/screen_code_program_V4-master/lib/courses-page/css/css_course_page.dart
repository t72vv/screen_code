import 'package:flutter/material.dart';
import 'package:project/courses-page/course_widget_page.dart';
import 'package:project/courses-page/css/css_course_lessons_page.dart';

class CssCourseWidget extends StatefulWidget {
  const CssCourseWidget({super.key});

  @override
  State<CssCourseWidget> createState() => _CssCourseWidgetState();
}

class _CssCourseWidgetState extends State<CssCourseWidget> {
  @override
  Widget build(BuildContext context) {
    return const CourseWidget(
      title: "Css course",
      img: "images/python_course_img.jpg",
      page: CssCourseLessonsWidget(),
    );
  }
}
