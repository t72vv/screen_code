import 'package:flutter/material.dart';
import 'package:project/courses-page/course_lessons_page.dart';
import 'package:project/courses_page.dart';
import 'package:project/video_card_page.dart';

class PythonCourseLessonsWidget extends StatefulWidget {
  const PythonCourseLessonsWidget({Key? key}) : super(key: key);

  @override
  State<PythonCourseLessonsWidget> createState() =>
      _PythonCourseLessonsWidgetState();
}

class _PythonCourseLessonsWidgetState extends State<PythonCourseLessonsWidget> {
  @override
  Widget build(BuildContext context) {
    return const CourseLessonsWidget(
      title: "Python course",
      img: "images/python_course_img.jpg",
      page: VideosDataWidget(),
    );
  }
}

class VideosDataWidget extends StatefulWidget {
  const VideosDataWidget({Key? key}) : super(key: key);

  @override
  State<VideosDataWidget> createState() => _VideosDataWidgitState();
}

class _VideosDataWidgitState extends State<VideosDataWidget> {
  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        for (Map<String, dynamic> videoData in videosData)
          VideoCardWidget(
            video_number: videoData['lesson_number'],
            video_title: videoData['lesson_title'],
            video_link: videoData['lesson_link'],
          ),
      ],
    );
  }
}
