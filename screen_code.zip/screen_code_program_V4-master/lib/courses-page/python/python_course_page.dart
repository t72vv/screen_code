import 'package:flutter/material.dart';
import 'package:project/courses-page/course_widget_page.dart';
import 'package:project/courses-page/python/python_course_lessons_page.dart';

class PythonCourseWidget extends StatefulWidget {
  const PythonCourseWidget({super.key});

  @override
  State<PythonCourseWidget> createState() => _PythonCourseWidgetState();
}

class _PythonCourseWidgetState extends State<PythonCourseWidget> {
  @override
  Widget build(BuildContext context) {
    return const CourseWidget(
      title: "Python course",
      img: "images/python_course_img.jpg",
      page: PythonCourseLessonsWidget(),
    );
  }
}
