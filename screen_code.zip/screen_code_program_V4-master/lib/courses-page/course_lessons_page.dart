import 'package:flutter/material.dart';
import 'package:project/appbar_page.dart';

class CourseLessonsWidget extends StatelessWidget {
  final String title;
  final String img;
  final Widget page;
  const CourseLessonsWidget(
      {super.key, required this.title, required this.img, required this.page});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      backgroundColor: const Color(0xFFeffffe),
      appBar: AppBarWidget(text: title),
      body: Container(
        color: const Color(0xFFeffffe),
        child: Column(
          children: [
            SizedBox(
              height: MediaQuery.of(context).size.width * 0.563,
              child: Image.asset(img),
            ),
            Container(
              padding: const EdgeInsets.all(4),
              margin: const EdgeInsets.all(4),
              height: MediaQuery.of(context).size.width * 0.13,
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    spreadRadius: 5,
                    blurRadius: 7,
                    offset: const Offset(0, 3), // changes position of shadow
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset("images_icons/lesson.png"),
                  const SizedBox(width: 15),
                  const Text(
                    "Course lessons",
                    style: TextStyle(fontSize: 28),
                  ),
                ],
              ),
            ),
            Expanded(
              child: page,
            ),
          ],
        ),
      ),
    ));
  }
}
