import 'package:flutter/material.dart';
import 'package:project/courses-page/c++/cpp_course_lessons_page.dart';
import 'package:project/courses-page/course_widget_page.dart';

class CppCourseWidget extends StatefulWidget {
  const CppCourseWidget({super.key});

  @override
  State<CppCourseWidget> createState() => _CppCourseWidgetState();
}

class _CppCourseWidgetState extends State<CppCourseWidget> {
  @override
  Widget build(BuildContext context) {
    return const CourseWidget(
      title: "C++ course",
      img: "images/python_course_img.jpg",
      page: CppCourseLessonsWidget(),
    );
  }
}
