import 'package:flutter/material.dart';
import 'package:project/courses-page/course_lessons_page.dart';
import 'package:project/data/cpp_lesson_data.dart';

class CppCourseLessonsWidget extends StatefulWidget {
  const CppCourseLessonsWidget({super.key});

  @override
  State<CppCourseLessonsWidget> createState() => _CppCourseLessonsWidgetState();
}

class _CppCourseLessonsWidgetState extends State<CppCourseLessonsWidget> {
  @override
  Widget build(BuildContext context) {
    return const CourseLessonsWidget(
      title: "C++ course",
      img: "images/python_course_img.jpg",
      page: CppLessonDataWidget(),
    );
  }
}
