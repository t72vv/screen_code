import 'package:flutter/material.dart';
import 'package:project/courses-page/course_widget_page.dart';
import 'package:project/courses-page/java/java_course_lessons_page.dart';

class JavaCourseWidget extends StatefulWidget {
  const JavaCourseWidget({super.key});

  @override
  State<JavaCourseWidget> createState() => _JavaCourseWidgetState();
}

class _JavaCourseWidgetState extends State<JavaCourseWidget> {
  @override
  Widget build(BuildContext context) {
    return const CourseWidget(
      title: "Java course",
      img: "images/python_course_img.jpg",
      page: JavaCourseLessonsWidget(),
    );
  }
}
