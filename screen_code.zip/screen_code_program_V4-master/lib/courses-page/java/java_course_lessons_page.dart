import 'package:flutter/material.dart';
import 'package:project/courses-page/course_lessons_page.dart';
import 'package:project/data/java_lesson_data.dart';

class JavaCourseLessonsWidget extends StatefulWidget {
  const JavaCourseLessonsWidget({super.key});

  @override
  State<JavaCourseLessonsWidget> createState() =>
      _JavaCourseLessonsWidgetState();
}

class _JavaCourseLessonsWidgetState extends State<JavaCourseLessonsWidget> {
  @override
  Widget build(BuildContext context) {
    return const CourseLessonsWidget(
      title: "Java course",
      img: "images/python_course_img.jpg",
      page: JavaLessonDataWidget(),
    );
  }
}
