import 'package:flutter/material.dart';
import 'package:project/auth/registre/view/LoginScreen%20.dart';
import 'package:project/profile_page.dart';

class MenuWidget extends StatefulWidget {
  const MenuWidget({
    super.key,
    required this.name,
  });
  final String name;

  @override
  State<MenuWidget> createState() => _MenuWidgetState();
}

class _MenuWidgetState extends State<MenuWidget> {
  @override
  Widget build(BuildContext context) {
    return Expanded(
        child: SizedBox(
      width: MediaQuery.of(context).size.width * 0.5,
      child: Drawer(
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.only(bottomRight: Radius.circular(360))),
        child: ListView(children: [
          UserAccountsDrawerHeader(
            currentAccountPicture: const CircleAvatar(
              backgroundImage: AssetImage("images/profile.png"),
            ),
            accountName: Text(widget.name),
            accountEmail: const Text(""),
          ),
          ListTile(
            leading: const Icon(Icons.person),
            title: const Text("Profile"),
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const ProfileWidget()));
            },
          ),
          ListTile(
            leading: const Icon(Icons.logout),
            title: const Text("Log out"),
            onTap: () {
              Navigator.of(context).pushReplacement(MaterialPageRoute(
                builder: (context) => const LoginScreen(),
              ));
            },
          ),
        ]),
      ),
    ));
  }
}
