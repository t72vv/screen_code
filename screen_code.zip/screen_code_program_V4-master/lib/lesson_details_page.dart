import 'package:flutter/material.dart';
import 'package:project/appbar_page.dart';
import 'package:webview_flutter/webview_flutter.dart';

class LessonDetailsWidgit extends StatefulWidget {
  final String appBar;
  final int lesson_number;
  final String lesson_title;
  final String lesson_link;
  const LessonDetailsWidgit(
      {super.key,
      required this.appBar,
      required this.lesson_number,
      required this.lesson_title,
      required this.lesson_link});

  @override
  State<LessonDetailsWidgit> createState() => _LessonDetailsWidgitState();
}

class _LessonDetailsWidgitState extends State<LessonDetailsWidgit> {
  late final WebViewController controller;

  int _lesson_number = 0;
  String _lesson_title = "";
  String _lesson_link = "";
  Widget _lesson = Container();

  @override
  void initState() {
    setState(() {
      _lesson_number = widget.lesson_number;
      _lesson_title = widget.lesson_title;
      _lesson_link = widget.lesson_link;
      _lesson = Container();
// استدعاء الصفحة
      controller = WebViewController()
        ..loadRequest(
          Uri.parse(_lesson_link),
        );
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: const Color(0xFFeffffe),
        appBar: AppBarWidget(text: widget.appBar),
        body: Expanded(
          child: Container(
            child: Column(
              children: [
                Container(
                  height: 60,
                  decoration: BoxDecoration(
                    borderRadius: const BorderRadius.vertical(
                        bottom: Radius.circular(20)),
                    color: const Color(0xFFbbf2fb),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 3,
                        blurRadius: 7,
                        offset: const Offset(0, 1),
                      ),
                    ],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.only(left: 20, right: 20),
                    child: Row(
                      mainAxisAlignment:
                          MainAxisAlignment.end, // تغيير المحاذاة هنا
                      children: [
                        Text(
                          _lesson_title,
                          style: const TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(width: 10),
                        const Icon(Icons.play_lesson_rounded),
                        const SizedBox(width: 10),
                        Text("$_lesson_number"),
                      ],
                    ),
                  ),
                ),
                //const SizedBox(height: 10),
                Container(
                    margin: const EdgeInsets.only(
                        left: 8, right: 8, top: 2, bottom: 2),
                    child: Column(
                      children: [
                        //Text("num vid = $_lesson_number"),
                        _lesson,
                      ],
                    )),
                Expanded(
                  child: Container(
                    margin: const EdgeInsets.only(left: 4, right: 4),
                    child: WebViewWidget(
                      controller: controller,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        // bottomNavigationBar: Container(
        //   padding: const EdgeInsets.all(4),
        //   decoration: BoxDecoration(
        //     borderRadius: const BorderRadius.only(
        //       topLeft: Radius.circular(20),
        //       topRight: Radius.circular(20),
        //     ),
        //     boxShadow: [
        //       BoxShadow(
        //         color: Colors.black.withOpacity(0.1),
        //         spreadRadius: 1,
        //         blurRadius: 12,
        //         offset: const Offset(0, 1),
        //       ),
        //     ],
        //   ),
        //   child: ClipRRect(
        //     borderRadius: const BorderRadius.only(
        //       topLeft: Radius.circular(20),
        //       topRight: Radius.circular(20),
        //     ),
        //     child: BottomAppBar(
        //       shape: const CircularNotchedRectangle(),
        //       color: Colors.white,
        //       child: Row(
        //         mainAxisAlignment: MainAxisAlignment.spaceAround,
        //         children: [
        //           Expanded(
        //             child: InkWell(
        //               onTap: () {},
        //               child: const Column(
        //                 mainAxisSize: MainAxisSize.min,
        //                 children: [
        //                   Icon(Icons.arrow_back_ios),
        //                   Text("back"),
        //                 ],
        //               ),
        //             ),
        //           ),
        //           Expanded(
        //             child: SizedBox(
        //               width: MediaQuery.of(context).size.height * 0.01,
        //             ),
        //           ),
        //           Expanded(
        //             child: SizedBox(
        //               width: MediaQuery.of(context).size.height * 0.01,
        //             ),
        //           ),
        //           Expanded(
        //             child: InkWell(
        //               onTap: () {
        //                 Navigator.push(
        //                     context,
        //                     MaterialPageRoute(
        //                         builder: (context) => TestWidgit(
        //                               appBar: widget.appBar,
        //                               lesson_number: _lesson_number,
        //                               lesson_title: _lesson_title,
        //                             )));
        //               },
        //               child: const Column(
        //                 mainAxisSize: MainAxisSize.min,
        //                 children: [
        //                   Icon(Icons.arrow_forward_ios),
        //                   Text("next"),
        //                 ],
        //               ),
        //             ),
        //           ),
        //         ],
        //       ),
        //     ),
        //   ),
        // ),
      ),
    );
  }
}
