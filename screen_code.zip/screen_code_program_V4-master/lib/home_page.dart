import 'package:flutter/material.dart';
import 'package:project/appbar_page.dart';
import 'package:project/menu_page.dart';

class HomeWidgit extends StatefulWidget {
  const HomeWidgit({Key? key, required this.name}) : super(key: key);
  final String name;

  @override
  State<HomeWidgit> createState() => _HomeWidgitState();
}

class _HomeWidgitState extends State<HomeWidgit> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: MenuWidget(name: widget.name),
      backgroundColor: const Color(0xFFeffffe),
      appBar: const AppBarWidget(text: "Home"),
      body: SingleChildScrollView(
        child: Container(
          child: Column(children: [
            Container(
              height: 60,
              decoration: BoxDecoration(
                borderRadius:
                    const BorderRadius.vertical(bottom: Radius.circular(20)),
                color: const Color(0xFFbbf2fb),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    spreadRadius: 3,
                    blurRadius: 7,
                    offset: const Offset(0, 1),
                  ),
                ],
              ),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.handshake),
                  SizedBox(width: 10),
                  Text(
                    "Welcome to Screen Code",
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(10),
              child: const Row(children: [
                Icon(Icons.newspaper),
                Text("Latest Updates"),
              ]),
            ),
            Container(
              padding: const EdgeInsets.all(10),
              height: 37,
              width: MediaQuery.of(context).size.width * 0.8,
              decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(6))),
              child: const Text("Additional content Python"),
            ),
            SizedBox(
              width: MediaQuery.of(context).size.width * 0.8,
              child: Image.asset("images/0.png"),
            ),
            Container(
              padding: const EdgeInsets.all(10),
              child: const Row(children: [
                Icon(Icons.upcoming_outlined),
                Text("Upcoming"),
              ]),
            ),
            SizedBox(
              width: MediaQuery.of(context).size.width * 0.95,
              child: Image.asset("images/java.png"),
            ),
          ]),
        ),
      ),
    );
  }
}
