import 'package:flutter/material.dart';
import 'package:project/lesson_card_page.dart';

class JavaLessonDataWidget extends StatefulWidget {
  const JavaLessonDataWidget({
    super.key,
  });

  @override
  State<JavaLessonDataWidget> createState() => _JavaLessonDataWidgetState();
}

class _JavaLessonDataWidgetState extends State<JavaLessonDataWidget> {
  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        for (List<dynamic> lesson_data in java_lesson_data)
          LessonCardWidget(
            appBar: "Java course Lesson ",
            lesson_number: lesson_data[0],
            lesson_title: lesson_data[1],
            lesson_link: lesson_data[2],
          ),
      ],
    );
  }
}

List<dynamic> java_lesson_data = [
  [1, "مقدمة جافا", "https://harmash.com/tutorials/java/overview"],
  [
    2,
    "تهيئة بيئة العمل",
    "https://harmash.com/tutorials/java/environment-setup"
  ],
  [3, "أساسيات لغة جافا", "https://harmash.com/tutorials/java/basics"],
  [
    4,
    "أسلوب و مبادئ كتابة الكود في جافا",
    "https://harmash.com/tutorials/java/basic-syntax"
  ],
  [
    5,
    "كتابة أول برنامج في جافا",
    "https://harmash.com/tutorials/java/start-coding"
  ],
  [
    6,
    "أنواع البيانات في جافا",
    "https://harmash.com/tutorials/java/basic-data-types"
  ],
  [7, "المتغيرات في جافا", "https://harmash.com/tutorials/java/variables-type"],
  [8, "الدوال في جافا", "https://harmash.com/tutorials/java/methods"],
  [9, "العوامل في جافا", "https://harmash.com/tutorials/java/operators"],
  [10, "الحلقات في جافا", "https://harmash.com/tutorials/java/loops"],
  [11, "الشروط في جافا", "https://harmash.com/tutorials/java/conditions"],
  [
    12,
    "التعامل مع الأعداد في جافا",
    "https://harmash.com/tutorials/java/numbers"
  ],
  [
    13,
    "التعامل مع الأحرف في جافا",
    "https://harmash.com/tutorials/java/characters"
  ],
  [
    14,
    "التعامل مع النصوص في جافا",
    "https://harmash.com/tutorials/java/strings"
  ],
  [
    15,
    "التعامل مع المصفوفات في جافا",
    "https://harmash.com/tutorials/java/arrays"
  ],
  [
    16,
    "التاريخ و الوقت في جافا",
    "https://harmash.com/tutorials/java/date-and-time"
  ],
  [17, "التعابير النمطية في جافا", "https://harmash.com/tutorials/java/regex"],
  [18, "الإستثناءات في جافا", "https://harmash.com/tutorials/java/exceptions"],
  [
    19,
    "الكلاس و الكائن في جافا",
    "https://harmash.com/tutorials/java/class-and-object"
  ],
  [20, "الـ Modifiers في جافا", "https://harmash.com/tutorials/java/modifiers"],
  [21, "التغليف في جافا", "https://harmash.com/tutorials/java/encapsulation"],
  [22, "الوراثة في جافا", "https://harmash.com/tutorials/java/inheritance"],
  [23, "  Overriding  ", "https://harmash.com/tutorials/java/overriding"],
  [24, "  Overloading  ", "https://harmash.com/tutorials/java/overloading"],
  [
    25,
    "تحويل الأنواع في جافا",
    "https://harmash.com/tutorials/java/type-casting"
  ],
  [26, "التجريد في جافا", "https://harmash.com/tutorials/java/abstraction"],
  [27, "الإنترفيس في جافا", "https://harmash.com/tutorials/java/interfaces"],
  [
    28,
    "تعدد الأشكال في جافا",
    "https://harmash.com/tutorials/java/polymorphism"
  ],
  [
    29,
    "الكلاسات المتداخلة في جافا",
    "https://harmash.com/tutorials/java/nested-classes"
  ],
  [30, "النوع enum في جافا", "https://harmash.com/tutorials/java/enum"],
  [
    31,
    "إدخال البيانات في جافا",
    "https://harmash.com/tutorials/java/user-inputs"
  ],
  [
    32,
    "التعامل مع الملفات في جافا",
    "https://harmash.com/tutorials/java/files-io"
  ],
  [
    33,
    "مفهوم المزامنة في جاف",
    "https://harmash.com/tutorials/java/serialization"
  ],
  [
    34,
    "كلاسات الـ Data Structure الجاهزة في جافا",
    "https://harmash.com/tutorials/java/data-structure"
  ],
  [
    35,
    "الإطار Collection في جافا",
    "https://harmash.com/tutorials/java/collection"
  ],
  [36, "مفهوم التعميم في جافا", "https://harmash.com/tutorials/java/generics"],
  [
    37,
    "التعامل مع الشبكات في جافا",
    "https://harmash.com/tutorials/java/networking"
  ],
  [
    38,
    "تعدد المهام في جافا",
    "https://harmash.com/tutorials/java/multithreading"
  ],
  [
    39,
    "التعامل مع قواعد البيانات في جافا",
    "https://harmash.com/tutorials/java/jdbc"
  ],
  [
    40,
    "أسلوب Lambda في جافا",
    "https://harmash.com/tutorials/java/lambda-expressions"
  ],
  [
    41,
    "خطوتك التالية بعد تعلم لغة جافا",
    "https://harmash.com/tutorials/java/next-step"
  ],
];
