List<dynamic> videos_data = [
  //	1
  [
    1,
    "مقدمة الدورة التدريبية",
    "https://youtu.be/Wv9cwHQORVo?si=ZzNPAloloLKkurkW"
  ],
//	2
  [
    2,
    "تثبيت الباي تشارم والبايثون",
    "https://youtu.be/v03HehbBVQM?si=bJ03fHkjNn1HSQgj"
  ],
//	3
  [3, "IDEL", "https://youtu.be/xsCkP3AffMU?si=-5WEOAXRSSrVZc1k"],
//	4
  [4, "جملة الطباعة", "https://youtu.be/ZfFh6K5HleY?si=ELjjvnmXI7S94f2y"],
//	5
  [5, "التعليقات", "https://youtu.be/wxuKWc5GpTg?si=_E0eIYcWTdRxrRRz"],
//	6
  [6, "المسافة البادئة", "https://youtu.be/ipb13fPntfw?si=A1Q_QL9kLw2blRvj"],
//	7
  [
    7,
    "تمثيل العمليات الحسابية",
    "https://youtu.be/FzHjeEUglfc?si=xnzcfM2jR7Mlp4Nu"
  ],
//	8
  [8, "المتغيرات", "https://youtu.be/EkXg4fjhmrg?si=-JhXQc370uL7p6J5"],
//	9
  [9, "أنواع البيانات", "https://youtu.be/SktLOQ7Lq7U?si=c4zAAcCybmD0bIjJ"],
//	10
  [
    10,
    "التحويل بين أنواع البيانات",
    "https://youtu.be/mLGt7PTK4mE?si=-hsgw7dqqCGP7C2Y"
  ],
//	11
  [
    11,
    "العمليات الحسابية الجزء الأول",
    "https://youtu.be/oZ2AYX3vB9Y?si=ydqw88ZepBWe0fSu"
  ],
//	12
  [
    12,
    "العمليات الحسابية الجزء الثاني",
    "https://youtu.be/0xXDGWLSuBc?si=1xlcZz8lUQ0QAGUM"
  ],
//	13
  [
    13,
    "ايجاد القيمة الاكبر باستخدام max()",
    "https://youtu.be/wBaNmAyTjGg?si=aaomsMJi7DA5716M"
  ],
//	14
  [
    14,
    "ايجاد القيمة الاصغر باستخدام دالة min()",
    "https://youtu.be/K7a3EsRkEKg?si=466gfXoN6e8ajMCm"
  ],
//	15
  [
    15,
    "مرفوع القوة (الاس) باستخدام الدالة pow()",
    "https://youtu.be/dtUVriVWotQ?si=w3a5GIgsJDYiYqz3"
  ],
//	16
  [
    16,
    "التقريب الى أقرب عدد صحيح  باستخدام round()",
    "https://youtu.be/Iv7k171kDas?si=PwwZVvwMq0hMHcBO"
  ],
//	17
  [
    17,
    "تحويل الاعداد السالبة الى اعداد موجبة abs()",
    "https://youtu.be/x2XrBXqNdM8?si=BWvi2FsgOBssAmO9"
  ],
//	18
  [
    18,
    "إيجاد المجموع باستخدام الدالة sum()",
    "https://youtu.be/nd3vOxMAiiI?si=YnirKN_w5fr626OJ"
  ],
//	19
  [
    19,
    "إيجاد القسمة و باقي القسمة",
    "https://youtu.be/llmQg-ZzRtg?si=cw_GC4LA8mQsL1KP"
  ],
//	20
  [
    20,
    "اختصار القيم بعد الفاصلة",
    "https://youtu.be/LtaH2mRxYBY?si=VmiA3XuajNY7qpSC"
  ],
//	21
  [
    21,
    "تمرين العمليات الحسابية",
    "https://youtu.be/08Tuq2cZwoU?si=JgyQejIoSHsMy9r7"
  ],
//	22
  [22, "عوامل المقارنة", "https://youtu.be/mZBFzIuWpDA?si=POgg22OGzB2KNYJ_"],
//	23
  [23, "العمليات المنطقية", "https://youtu.be/u6PQG-mxi0c?si=2_GEaxMZNGUMB6-S"],
//	24
  [
    24,
    "حل تمارين عمليات المقارنة والعمليات المنطقية",
    "https://youtu.be/IRx1Js-IaBc?si=i2iwENY4ZX9dcgwO"
  ],
//	25
  [
    25,
    "ادخال البيانات من قبل المستخدم",
    "https://youtu.be/eWRP7tAFAeY?si=cOuDZ-U8TbgIMHF5"
  ],
//	26
  [26, "الشروط ", "https://youtu.be/y1RKuSh04yE?si=XgBApiPPDKTTXbKI"],
//	27
  [
    27,
    "الجملة الشرطية if الجزء الاول",
    "https://youtu.be/S5wBl4dvgI8?si=OGnlYvgGlSFqZ0A5"
  ],
//	28
  [
    28,
    "الجملة الشرطية if الجزء الثاني",
    "https://youtu.be/1DBht__z7UA?si=80ki8wAMBgwB-GVV"
  ],
//	29
  [
    29,
    "الجملة الشرطية if الجزء الثالث",
    "https://youtu.be/J7nfBclmf0Q?si=Jr-fM1YSBV2cO1nS"
  ],
//	30
  [
    30,
    "تطبيق عملي على الشروط",
    "https://youtu.be/47YeNQ3t1kI?si=r_NNRo0MWFW2YCOV"
  ],
//	31
  [31, "الشروط المتداخلة", "https://youtu.be/TD7Hru41Cw0?si=NjdLxJdF6E3JHJUQ"],
//	32
  [
    32,
    "جملة التكرار for loop",
    "https://youtu.be/LJjBii4mfn8?si=veyFVDOe_lXyZLdi"
  ],
//	33
  [
    33,
    "جملة التكرار for loop التعامل مع range",
    "https://youtu.be/l6mobf8b6rQ?si=ssy-BloDWd4GXYZw"
  ],
//	34
  [
    34,
    "طباعة الاعداد الفردية والزوجية باستخدام for",
    "https://youtu.be/c8DDF4KXdSg?si=cyDZH-7ZMUTxOC9r"
  ],
//	35
  [
    35,
    "تمربن على جملة التكرار for loop",
    "https://youtu.be/2xnd_f9ssAw?si=rDQKH6s-rkjqt7ej"
  ],
//	36
  [
    36,
    "جملة التكرار While loop",
    "https://youtu.be/Cq5anxZntsA?si=1Z3K8iCiDx0tIF_D",
  ],
//	37
  [
    37,
    "مثال عملي على جملة التكرار While loop",
    "https://youtu.be/3ZgE6JXtyIA?si=pzOHw1Q5Bg94xNsS",
  ],
//	38
  [
    38,
    "الاعداد الفردية والزوجية باستخدام while loop",
    "https://youtu.be/KdRLUyS9_xw?si=YoDHMJPz3LLMW3HZ",
  ],
//	39
  [
    39,
    "جملة Break",
    "https://youtu.be/nsaW7dkpZZc?si=VXK7F06qxQkv2i9Y",
  ],
//	40
  [
    40,
    "جملة Continue ",
    "https://youtu.be/i-6lu5J_RPs?si=2QD3IYCmwjdHCp9K",
  ],
//	41
  [
    41,
    "جملة Pass",
    "https://youtu.be/73Nx04VZyPg?si=_u2y1mBEQWf-Fx7m",
  ],
//	42
  [
    42,
    "تمرين شامل على جمل التكرار والجمل الشرطية",
    "https://youtu.be/d2gaOqBin4A?si=sFg4qOy1gIFLXHZ5",
  ],
//	43
  [
    43,
    "الحلقات المتداخلة",
    "https://youtu.be/9BDR-ycRyFk?si=7FL-VimQgQ_48fuD",
  ],
//	44
  [
    44,
    "القوائم list والتعامل معها",
    "https://youtu.be/aZUGhU2n_HQ?si=ks-03wC6ygAYY60v",
  ],
//	45
  [
    45,
    "الصفوف Tuple والتعامل معها",
    "https://youtu.be/PY8dRETnges?si=_gU349Midh7a91gT",
  ],
//	46
  [
    46,
    "القوائم list والتعامل معها الجزء الثاني",
    "https://youtu.be/HtOsZeDxJEY?si=HxchdQo4mGMYFSN7",
  ],
//	47
  [
    47,
    "تمارين على القوائم list",
    "https://youtu.be/BIyEhhMKD-g?si=i7FNc7oTPt1NGd1l",
  ],
//	48
  [
    48,
    "امثلة على العمليات على القوائم",
    "https://youtu.be/OuphW3acgQQ?si=8xy8agn8RQH1W-Gw",
  ],
//	49
  [
    49,
    "List Comprehension",
    "https://youtu.be/pfMd8dt35N4?si=y5d1xRUz8IVb3DcK",
  ],
//	50
  [
    50,
    "Dictionaries",
    "https://youtu.be/IBP1HTtvU-k?si=D9BdLxqoinkoSd1k",
  ],
//	51
  [
    51,
    "القوائم ذات البعدين",
    "https://youtu.be/-1xDukY38mQ?si=uKy8LyJpIbYykjah",
  ],
//	52
  [
    52,
    "الدوال - Functions ",
    "https://youtu.be/LYbmMPxq7qk?si=lHBKkvzMLM20vf8S",
  ],
//	53
  [
    53,
    "الدوال المتداخلة",
    "https://youtu.be/81UMFxBSKhU?si=NQ_6pMW7lynpI31y",
  ],
//	54
  [
    54,
    "ايجاد المتوسط الحسابي",
    "https://youtu.be/-Zcz-5qSrPc?si=F2WXgmBEgkKwMLph",
  ],
//	55
  [
    55,
    "انشاء دالة لايجاد المتوسط الحسابي",
    "https://youtu.be/7bQXOIrlRhc?si=2lxqa-h7mOwMiM-X",
  ],
//	56
  [
    56,
    "مثال على استخدام اكثر من دالة في نفس الوقت",
    "https://youtu.be/_RICgKTqv28?si=8E_fES1MYAp8tgRq",
  ],
//	57
  [
    57,
    "استدعاء دالة من داخل دالة اخرى",
    "https://youtu.be/TUtnFkbH9SA?si=w0lM6IYksw5mXHZC",
  ],
//	58
  [
    58,
    "تمرين على الدوال والمتوسط الحسابي",
    "https://youtu.be/mTTMlAQqMNM?si=dM-WJ0QmKgB3trNp",
  ],
//	59
  [
    59,
    "انشاء الة حاسبة بسيطة",
    "https://youtu.be/Chf-OpUvALw?si=uS105Efn8uiww7C2",
  ],
//	60
  [
    60,
    "ايجاد مساحة الدائرة",
    "https://youtu.be/m9LrBLsnbM0?si=gGtBY4Gw2BHkm_zT",
  ],
//	61
  [
    61,
    "ايجاد مساحة الدائرة باستخدام دالة",
    "https://youtu.be/LI_op9_Az6o?si=mH-hLe1fNdUX_R8W",
  ],
//	62
  [
    62,
    "التحقق من العدد هل هو من مضاعفات العدد خمسة",
    "https://youtu.be/KILWqNmD534?si=BO1Fid7t1T2TyzO4",
  ],
//	63
  [
    63,
    "برنامج يتحقق من قابلية القسمة على 2",
    "https://youtu.be/Ak54k_xth6I?si=jZNq9vlQkbqEsx-b",
  ],
//	64
  [
    64,
    "انشاء قيم عشوائية - Random ",
    "https://youtu.be/9ZdsWHejP_M?si=NCs0fuwJTYVrQ4h0",
  ],
//	65
  [
    65,
    "برنامج انشاء قيم عشوائية واجراء عمليات حسابيه ",
    "https://youtu.be/-ZcaXwRhVfQ?si=2Ks-DqJyLKcrYzKV",
  ],
//	66
  [
    66,
    "النصوص والتعامل معها",
    "https://youtu.be/MtMdswsIde8?si=81nv5mm04zqfu5gv",
  ],
//	67
  [
    67,
    "تحويل جميع الاحرف الى أحرف كبيرة",
    "https://youtu.be/vbEE1Yxyx2M?si=jRopElMxrCD3fmpc",
  ],
//	68
  [
    68,
    "تحويل جميع الاحرف الى أحرف صغيرة",
    "https://youtu.be/irqjI-KASmY?si=YBjDsjmOwgJ4jdUc",
  ],
//	69
  [
    69,
    "التحقق من حالة جميع الاحرف هل هي احرف كبيرة",
    "https://youtu.be/FfobsxAybnk?si=ePpf-j34aC4JllaV",
  ],
//	70
  [
    70,
    "التحقق من حالة جميع الاحرف هل هي احرف صغيرة",
    "https://youtu.be/1Cse9iklSUY?si=dXsLgrht-0YZUJHe",
  ],
//	71
  [
    71,
    "تحويل اول حرف الى حرف كبير",
    "https://youtu.be/0U8rEKQHbTs?si=EMccE6k1dYB6yB5c",
  ],
//	72
  [
    72,
    "إضافة مسافة بين الاحرف او رمز",
    "https://youtu.be/U-SYJQDlmqE?si=6PiRe8tRUBLDcT1Z",
  ],
//	73
  [
    73,
    "تقسيم عناصر الجملة النصية الى list",
    "https://youtu.be/dKd7Q8XKiLk?si=rikfM1QlSUz5qZM2",
  ],
//	74
  [
    74,
    "استبدال كلمة بكلمة أخرى او حرف بحرف اخر",
    "https://youtu.be/4Pe3cuiCAJ8?si=oN_fNq1zPYFJuppX",
  ],
//	75
  [
    75,
    "معرفة طول الجملة النصية",
    "https://youtu.be/KSCbR-y4N5s?si=tx2Fk0ViJ_yWkA4p",
  ],
//	76
  [
    76,
    " إيجاد موقع الحرف او الكلمة",
    "https://youtu.be/fWkpJCcXvVc?si=KXwfPQlX2fFNcuMj",
  ],
//	77

//	78
//	79
//	80
//	81
//	82
//	83
//	84
//	85
];
