import 'package:flutter/material.dart';
import 'package:project/lesson_card_page.dart';

class CppLessonDataWidget extends StatefulWidget {
  const CppLessonDataWidget({
    super.key,
  });

  @override
  State<CppLessonDataWidget> createState() => _CppLessonDataWidgetState();
}

class _CppLessonDataWidgetState extends State<CppLessonDataWidget> {
  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        for (List<dynamic> lesson_data in cpp_lesson_data)
          LessonCardWidget(
            appBar: "C++ course Lesson ",
            lesson_number: lesson_data[0],
            lesson_title: lesson_data[1],
            lesson_link: lesson_data[2],
          ),
      ],
    );
  }
}

List<dynamic> cpp_lesson_data = [
  [
    1,
    " تعلم لغة سي بلس بلس",
    "https://harmash.com/tutorials/cplusplus/overview"
  ],
  [
    2,
    "  تحميل و تثبيت أدوات سي بلس بلس",
    "https://harmash.com/tutorials/cplusplus/environment-setup"
  ],
  [
    3,
    "  أسلوب كتابة الكود في سي بلس بلس",
    "https://harmash.com/tutorials/cplusplus/basic-syntax"
  ],
  [4, "أنواع البيانات  ", "https://harmash.com/tutorials/cplusplus/data-types"],
  [5, "المتغيرات  ", "https://harmash.com/tutorials/cplusplus/variables"],
  [6, "  العوامل", "https://harmash.com/tutorials/cplusplus/operators"],
  [7, "  الشروط", "https://harmash.com/tutorials/cplusplus/conditions"],
  [8, "الحلقات  ", "https://harmash.com/tutorials/cplusplus/loops"],
  [
    9,
    " التعامل مع الأعداد ",
    "https://harmash.com/tutorials/cplusplus/numbers"
  ],
  [
    10,
    "    التعامل مع النصوص",
    "https://harmash.com/tutorials/cplusplus/strings"
  ],
  [11, "    المصفوفات", "https://harmash.com/tutorials/cplusplus/arrays"],
  [
    12,
    "    إدخال بيانات من المستخدم",
    "https://harmash.com/tutorials/cplusplus/user-inputs"
  ],
  [13, "    الدوال", "https://harmash.com/tutorials/cplusplus/functions"],
  [14, "    المراجع", "https://harmash.com/tutorials/cplusplus/references"],
  [15, "   المؤشرات", "https://harmash.com/tutorials/cplusplus/pointers"],
  [
    16,
    "  مفهوم البرمجة الكائنية (OOP)",
    "https://harmash.com/tutorials/cplusplus/oop"
  ],
  [17, "    النوع struct", "https://harmash.com/tutorials/cplusplus/struct"],
  [18, "النوع class   ", "https://harmash.com/tutorials/cplusplus/class"],
  [19, "التغليف  ", "https://harmash.com/tutorials/cplusplus/encapsulation"],
  [20, "الوراثة  ", "https://harmash.com/tutorials/cplusplus/inheritance"],
  [21, "  Overriding  ", "https://harmash.com/tutorials/cplusplus/overriding"],
  [
    22,
    "  Overloading  ",
    "https://harmash.com/tutorials/cplusplus/overloading"
  ],
  [
    23,
    "   تعدد الأشكال",
    "https://harmash.com/tutorials/cplusplus/polymorphism"
  ],
  [24, "التجريد في جافا", "https://harmash.com/tutorials/java/abstraction"],
  [25, "  الثوابت", "https://harmash.com/tutorials/cplusplus/constants"],
  [26, "   النوع enum", "https://harmash.com/tutorials/cplusplus/enum"],
  [
    27,
    "   معالجة الأخطاء",
    "https://harmash.com/tutorials/cplusplus/exceptions"
  ],
  [
    28,
    "التعامل مع الملفات   ",
    "https://harmash.com/tutorials/cplusplus/files"
  ],
  [29, "   التعميم", "https://harmash.com/tutorials/cplusplus/generics"],
  [
    30,
    "    الحاويات الديناميكية",
    "https://harmash.com/tutorials/cplusplus/stl"
  ],
  [
    31,
    "   Lambda Expressions",
    "https://harmash.com/tutorials/cplusplus/lambda-expressions"
  ],
  [
    32,
    " تعدد المهام     ",
    "https://harmash.com/tutorials/cplusplus/multithreading"
  ],
  [
    33,
    "تضمين الملفات   ",
    "https://harmash.com/tutorials/cplusplus/include-files"
  ],
  [
    34,
    "   التعامل مع المكتبات",
    "https://harmash.com/tutorials/cplusplus/libraries"
  ],
];
