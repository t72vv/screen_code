import 'package:flutter/material.dart';
import 'package:project/lesson_card_page.dart';

class HTMLLessonDataWidget extends StatefulWidget {
  const HTMLLessonDataWidget({
    super.key,
  });

  @override
  State<HTMLLessonDataWidget> createState() => _HTMLLessonDataWidgetState();
}

class _HTMLLessonDataWidgetState extends State<HTMLLessonDataWidget> {
  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        for (List<dynamic> lesson_data in html_lesson_data)
          LessonCardWidget(
            appBar: "HTML course Lesson ",
            lesson_number: lesson_data[0],
            lesson_title: lesson_data[1],
            lesson_link: lesson_data[2],
          ),
      ],
    );
  }
}

List<dynamic> html_lesson_data = [
  [1, "     تعلم لغة HTML  ", "https://harmash.com/tutorials/html/overview"],
  [2, "     المحررات", "https://harmash.com/tutorials/html/editors"],
  [3, "     أساسيات اللغة", "https://harmash.com/tutorials/html/basics"],
  [4, "      الفقرات  ", "https://harmash.com/tutorials/html/paragraphs"],
  [5, " العناوين", "https://harmash.com/tutorials/html/heading"],
  [6, " تنسيق النصوص  ", "https://harmash.com/tutorials/html/formatting"],
  [7, "الحلقات ", "https://harmash.com/tutorials/javascript/loops"],
  [8, "   الإقتباسات ", "https://harmash.com/tutorials/html/quotations"],
  [9, "    تنسيق الكود", "https://harmash.com/tutorials/html/computer-code"],
  [10, "الروابط  ", "https://harmash.com/tutorials/html/links"],
  [11, "  الجداول  ", "https://harmash.com/tutorials/html/tables"],
  [
    12,
    "    القوائم المرتبة",
    "https://harmash.com/tutorials/html/ordered-lists"
  ],
  [
    13,
    "    القوائم الغير مرتبة",
    "https://harmash.com/tutorials/html/unordered-lists"
  ],
  [
    14,
    "     قوائم الوصف   ",
    "https://harmash.com/tutorials/html/description-lists"
  ],
  [15, "     مسارات الملفات", "https://harmash.com/tutorials/html/files-paths"],
  [16, "    الصور", "https://harmash.com/tutorials/html/images"],
  [17, "  الفيديوهات", "https://harmash.com/tutorials/html/videos"],
  [18, "   الصوتيات ", "https://harmash.com/tutorials/html/audios"],
  [19, "      النماذج ", "https://harmash.com/tutorials/html/forms"],
  [20, "الأطر      ", "https://harmash.com/tutorials/html/iframes"],
  [21, "  عنونة عناصر النموذج  ", "https://harmash.com/tutorials/html/labels"],
  [22, "  حقول الإدخال  ", "https://harmash.com/tutorials/html/input-fields"],
  [23, "    الأزرار العادية  ", "https://harmash.com/tutorials/html/buttons"],
  [24, "  خانات الإختيار  ", "https://harmash.com/tutorials/html/checkboxes"],
  [
    25,
    "     أزرار الراديو ",
    "https://harmash.com/tutorials/html/radio-buttons"
  ],
  [26, "   القوائم المنسدلة", "https://harmash.com/tutorials/html/ranges"],
  [
    27,
    "    تجميع عناصر النموذج المشتركة",
    "https://harmash.com/tutorials/html/fields-sets"
  ],
  [
    28,
    "    تحديد إتجاه المحتوى ",
    "https://harmash.com/tutorials/html/content-direction"
  ],
  [29, "     رموز اللغات", "https://harmash.com/tutorials/javascript/history"],
  [
    30,
    "   رموز البلدان   ",
    "https://harmash.com/tutorials/html/country-codes"
  ],
  [
    31,
    "   الصفحات المترجمة",
    "https://harmash.com/tutorials/html/translated-pages"
  ],
];
