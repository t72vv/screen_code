import 'package:flutter/material.dart';
import 'package:project/lesson_card_page.dart';

class JSLessonDataWidget extends StatefulWidget {
  const JSLessonDataWidget({
    super.key,
  });

  @override
  State<JSLessonDataWidget> createState() => _JSLessonDataWidgetState();
}

class _JSLessonDataWidgetState extends State<JSLessonDataWidget> {
  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        for (List<dynamic> lesson_data in js_lesson_data)
          LessonCardWidget(
            appBar: "JavaScript course Lesson ",
            lesson_number: lesson_data[0],
            lesson_title: lesson_data[1],
            lesson_link: lesson_data[2],
          ),
      ],
    );
  }
}

List<dynamic> js_lesson_data = [
  [
    1,
    "   قواعد كتابة الكود  ",
    "https://harmash.com/tutorials/javascript/syntax"
  ],
  [
    2,
    "  كتابة أول كود جافاسكربت",
    "https://harmash.com/tutorials/javascript/getting-started"
  ],
  [3, "     المتغيرات", "https://harmash.com/tutorials/javascript/data-types"],
  [4, "      أنواع البيانات ", "https://harmash.com/tutorials/cplusplus/cout"],
  [5, " العوامل", "https://harmash.com/tutorials/javascript/operators"],
  [6, " الشروط  ", "https://harmash.com/tutorials/javascript/conditions"],
  [7, "الحلقات ", "https://harmash.com/tutorials/javascript/loops"],
  [
    8,
    "  التعامل مع الأعداد",
    "https://harmash.com/tutorials/javascript/numbers"
  ],
  [
    9,
    "  التعامل مع النصوص",
    "https://harmash.com/tutorials/javascript/strings"
  ],
  [10, "المصفوفات  ", "https://harmash.com/tutorials/javascript/arrays"],
  [11, "  الدوال  ", "https://harmash.com/tutorials/javascript/functions"],
  [
    12,
    "   الدوال السهمية",
    "https://harmash.com/tutorials/javascript/arrow-functions"
  ],
  [13, "    الكائنات", "https://harmash.com/tutorials/javascript/objects"],
  [
    14,
    "    معالجة الأخطاء   ",
    "https://harmash.com/tutorials/javascript/errors-handling"
  ],
  [15, "    البرمجة الكائنية", "https://harmash.com/tutorials/javascript/oop"],
  [16, "    الكلاس", "https://harmash.com/tutorials/javascript/classes"],
  [
    17,
    " الدوال الثابتة",
    "https://harmash.com/tutorials/javascript/static-methods"
  ],
  [18, "  ما هو DOM", "https://harmash.com/tutorials/javascript/html-dom"],
  [
    19,
    "    الوصول لعناصر الصفحة ",
    "https://harmash.com/tutorials/javascript/dom-selectors"
  ],
  [
    20,
    "إضافة / حذف عناصر    ",
    "https://harmash.com/tutorials/javascript/dom-manipulation"
  ],
  [
    21,
    "تعديل تصميم العناصر  ",
    "https://harmash.com/tutorials/javascript/dom-styling"
  ],
  [
    22,
    "الوصول لخصائص العناصر  ",
    "https://harmash.com/tutorials/javascript/dom-elements-attributes"
  ],
  [
    23,
    "  التنقل بين العناصر  ",
    "https://harmash.com/tutorials/javascript/dom-navigation"
  ],
  [24, "  الأحداث  ", "https://harmash.com/tutorials/javascript/dom-events"],
  [25, "    ما هو BOM", "https://harmash.com/tutorials/javascript/html-bom"],
  [26, "  خصائص الصفحة", "https://harmash.com/tutorials/javascript/window"],
  [27, "  خصائص الشاشة", "https://harmash.com/tutorials/javascript/screen"],
  [28, "   رابط الصفحة ", "https://harmash.com/tutorials/javascript/location"],
  [29, "    سجل الصفحات", "https://harmash.com/tutorials/javascript/history"],
  [
    30,
    "  النوافذ المنبثقة   ",
    "https://harmash.com/tutorials/javascript/dialog-boxes"
  ],
  [31, "   المؤقتات", "https://harmash.com/tutorials/javascript/timers"],
  [32, "     الكوكيز", "https://harmash.com/tutorials/javascript/cookies"],
  [
    33,
    "   التخزين المحلي ",
    "https://harmash.com/tutorials/javascript/localstorage"
  ],
  [
    34,
    "  الجلسات     ",
    "https://harmash.com/tutorials/javascript/sessionstorage"
  ],
  [
    35,
    " معلومات المتصفح   ",
    "https://harmash.com/tutorials/javascript/navigator"
  ],
  [
    36,
    "     ما هي المزامنة",
    "https://harmash.com/tutorials/javascript/asynchronous"
  ],
];
