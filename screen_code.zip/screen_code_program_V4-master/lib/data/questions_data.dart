List<Map<String, dynamic>> questions = [
  {
    'question': 'Advantages of the Python programming language?',
    'answers': [
      'Easy to learn',
      'Code readability closer to English language',
      'Abundance of libraries',
      'All of the above'
    ],
    'correctAnswer': 'All of the above'
  },
  {
    'question': 'The correct way to save a Python file is?',
    'answers': ['name.py', 'name.python', 'name.pyh', 'Nothing from the above'],
    'correctAnswer': 'name.py'
  },
  {
    'question': 'To print a text in Python, we use the command?',
    'answers': [
      'System.out.println("نص");',
      'puts "نص"',
      'print("نص")',
      'Console.WriteLine("نص");'
    ],
    'correctAnswer': 'print("نص")'
  },
  {
    'question': 'To write a comment in Python, we use the symbol?',
    'answers': [
      '# This is a comment',
      '<!-- This is a comment in HTML -->',
      '// This is a comment',
      'Nothing from the above'
    ],
    'correctAnswer': '# This is a comment'
  },
  {
    'question': 'From the conditions of naming a variable in Python?',
    'answers': [
      'Not using a reserved word',
      'No spaces in the variable name',
      'Not starting the variable with a number',
      'All of the above'
    ],
    'correctAnswer': 'All of the above'
  },
  {
    'question': 'To define a list in Python, we use the following?',
    'answers': ['my_lise = ()', 'my_lise = []', 'my_lise = {}', 'my_lise = <>'],
    'correctAnswer': 'my_lise = []'
  },
  {
    'question': '?',
    'answers': ['', '', '', ''],
    'correctAnswer': ''
  },
  {
    'question': '?',
    'answers': ['', '', '', ''],
    'correctAnswer': ''
  },
  {
    'question': '?',
    'answers': ['', '', '', ''],
    'correctAnswer': ''
  },
  {
    'question': '?',
    'answers': ['', '', '', ''],
    'correctAnswer': ''
  },
  {
    'question': '?',
    'answers': ['', '', '', ''],
    'correctAnswer': ''
  },
];
