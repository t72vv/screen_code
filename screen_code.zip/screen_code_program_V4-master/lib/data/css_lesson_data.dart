import 'package:flutter/material.dart';
import 'package:project/lesson_card_page.dart';

class CssLessonDataWidget extends StatefulWidget {
  const CssLessonDataWidget({
    super.key,
  });

  @override
  State<CssLessonDataWidget> createState() => _CssLessonDataWidgetState();
}

class _CssLessonDataWidgetState extends State<CssLessonDataWidget> {
  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        for (List<dynamic> lesson_data in css_lesson_data)
          LessonCardWidget(
            appBar: "Css course Lesson ",
            lesson_number: lesson_data[0],
            lesson_title: lesson_data[1],
            lesson_link: lesson_data[2],
          ),
      ],
    );
  }
}

List<dynamic> css_lesson_data = [
  [1, "     تعلم لغة CSS  ", "https://harmash.com/tutorials/css/overview"],
  [2, "    قواعد كتابة كود ", "https://harmash.com/tutorials/css/syntax"],
  [
    3,
    "     تحديد العناصر",
    "https://harmash.com/tutorials/css/select-elements"
  ],
  [4, "       التعليقات ", "https://harmash.com/tutorials/css/comments"],
  [5, " الألوان", "https://harmash.com/tutorials/css/colors"],
  [6, " الخلفيات  ", "https://harmash.com/tutorials/css/background"],
  [7, "الحدود ", "https://harmash.com/tutorials/css/border"],
  [8, "    الهوامش الداخلية", "https://harmash.com/tutorials/css/padding"],
  [9, "    الهوامش الخارجية", "https://harmash.com/tutorials/css/margin"],
  [10, "أساليب العرض  ", "https://harmash.com/tutorials/css/display"],
  [11, "  العرض و الطول  ", "https://harmash.com/tutorials/css/dimension"],
  [12, "    الحدود الخارجية", "https://harmash.com/tutorials/css/outline"],
  [13, "    النصوص", "https://harmash.com/tutorials/css/text"],
  [14, "     الخطوط   ", "https://harmash.com/tutorials/css/font"],
  [15, "     تأثيرات الظل", "https://harmash.com/tutorials/css/shadows"],
  [16, "    الأيقونات", "https://harmash.com/tutorials/css/icons"],
  [17, " الروابط ", "https://harmash.com/tutorials/css/links"],
  [18, "   المحتوى الفائض ", "https://harmash.com/tutorials/css/overflow"],
  [19, "      تدفق العناصر ", "https://harmash.com/tutorials/css/float"],
  [20, "قوائم التعداد      ", "https://harmash.com/tutorials/css/lists"],
  [21, "  الجداول  ", "https://harmash.com/tutorials/css/table"],
  [22, "  مواقع العناصر  ", "https://harmash.com/tutorials/css/position"],
  [23, "  قوائم الروابط    ", "https://harmash.com/tutorials/css/navbar"],
  [24, "  القوائم المنسدلة  ", "https://harmash.com/tutorials/css/dropdowns"],
  [
    25,
    "     بداية و نهاية العنصر ",
    "https://harmash.com/tutorials/css/before-and-after"
  ],
  [26, "   العدادات", "https://harmash.com/tutorials/css/counters"],
  [27, "   الصور المقتطعة", "https://harmash.com/tutorials/css/image-sprites"],
  [
    28,
    "    محددات الخصائص ",
    "https://harmash.com/tutorials/css/attribute-selectors"
  ],
  [29, "     عناصر النماذج", "https://harmash.com/tutorials/css/forms"],
  [
    30,
    "   دوال الحسابات    ",
    "https://harmash.com/tutorials/css/math-functions"
  ],
  [
    31,
    "   إستعلامات الوسائط",
    "https://harmash.com/tutorials/css/media-queries"
  ],
  [32, "     وضع صورة كحدود", "https://harmash.com/tutorials/css/border-image"],
  [
    33,
    "    خلفيات متعددة ",
    "https://harmash.com/tutorials/css/multiple-backgrounds"
  ],
  [34, "  تدرج الألوان     ", "https://harmash.com/tutorials/css/gradients"],
  [
    35,
    "  الأعمدة المتعددة   ",
    "https://harmash.com/tutorials/css/multiple-columns"
  ],
  [
    36,
    "      تنسيق الصور و الفيديوهات ",
    "https://harmash.com/tutorials/css/object-fit-and-position"
  ],
];
