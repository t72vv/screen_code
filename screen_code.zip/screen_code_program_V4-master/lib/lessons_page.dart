/*
import 'package:flutter/material.dart';
import 'package:project/appbar_page.dart';
import 'package:project/video_play_page.dart';

class LessonsWidgit extends StatefulWidget {
  const LessonsWidgit({Key? key}) : super(key: key);

  @override
  State<LessonsWidgit> createState() => _HomePageState();
}

class _HomePageState extends State<LessonsWidgit> {
  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Scaffold(
        backgroundColor: const Color(0xFFeffffe),
        appBar: const AppBarWidget(text: "Python course Lesson "),
        body: Expanded(
          child: Container(
            child: Column(children: [
              Container(
                height: 60,
                decoration: BoxDecoration(
                  borderRadius:
                      const BorderRadius.vertical(bottom: Radius.circular(20)),
                  color: const Color(0xFFbbf2fb),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.5), // لون الظل
                      spreadRadius: 3, // نسبة انتشار الظل
                      blurRadius: 7, // نسبة وضوح الظل
                      offset: const Offset(0, 1), // إزاحة الظل
                    ),
                  ],
                ),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "مقدمة الدورة التدريبية",
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(width: 10),
                    Icon(Icons.play_lesson_rounded),
                  ],
                ),
              ),
              const SizedBox(height: 85),
              Container(
                  margin: const EdgeInsets.all(6),
                  child: const VideoPlayWidgit()),
            ]),
          ),
        ),
        bottomNavigationBar: Container(
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(20),
              topRight: Radius.circular(20),
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                spreadRadius: 1,
                blurRadius: 12,
                offset: const Offset(0, 1),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(20),
              topRight: Radius.circular(20),
            ),
            child: BottomAppBar(
              shape: const CircularNotchedRectangle(),
              color: Colors.white,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Expanded(
                    child: InkWell(
                      onTap: () {},
                      child: const Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.arrow_back_ios),
                          Text("previous"),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    width: MediaQuery.of(context).size.height * 0.25,
                  ),
                  Expanded(
                    child: InkWell(
                      onTap: () {},
                      child: const Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.arrow_forward_ios),
                          Text("next"),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
*/